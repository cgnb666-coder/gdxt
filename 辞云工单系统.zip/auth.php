<?php
// auth.php — 会话 / 登录态 / 角色与邮箱强绑定守卫（所有页面 include）
declare(strict_types=1);

require_once __DIR__ . '/db.php';

db_ensure_schema(); // 老库自动补齐邮箱验证字段

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

/**
 * 当前登录用户（数组或 null）。
 */
function current_user(): ?array
{
    static $user = false;
    if ($user !== false) {
        return $user;
    }
    $uid = $_SESSION['uid'] ?? null;
    if (!$uid) {
        return $user = null;
    }
    $st = db()->prepare('SELECT * FROM users WHERE id = ? LIMIT 1');
    $st->execute([(int)$uid]);
    $row = $st->fetch();
    return $user = ($row ?: null);
}

/**
 * 要求已登录，否则跳登录页。
 */
function require_login(): array
{
    $u = current_user();
    if (!$u) {
        $to = $_SERVER['REQUEST_URI'] ?? '';
        header('Location: login.php?next=' . urlencode($to));
        exit;
    }
    return $u;
}

/**
 * 要求客服角色。
 */
function require_agent(): array
{
    $u = require_login();
    if ($u['role'] !== 'agent') {
        header('Location: ticket_list.php');
        exit;
    }
    return $u;
}

/**
 * 是否已完成 QQ 绑定（qq_bindings 存在该 user_id，且与当前 bot_app_id 匹配）。
 */
function is_bound(int $userId): bool
{
    $appId = (string)setting_get('qq_app_id', config()['qq']['app_id'] ?? '');
    if ($appId === '') {
        return false;
    }
    $st = db()->prepare('SELECT id FROM qq_bindings WHERE user_id = ? AND bot_app_id = ? LIMIT 1');
    $st->execute([$userId, $appId]);
    return (bool)$st->fetch();
}

/**
 * 取绑定记录。
 */
function get_binding(int $userId): ?array
{
    $appId = (string)setting_get('qq_app_id', config()['qq']['app_id'] ?? '');
    $st = db()->prepare('SELECT * FROM qq_bindings WHERE user_id = ? AND bot_app_id = ? LIMIT 1');
    $st->execute([$userId, $appId]);
    $row = $st->fetch();
    return $row ?: null;
}

/**
 * 【核心业务规则】业务页守卫：
 * 只有 customer 角色必须完成邮箱验证，未验证则 302 到 verify_email.php；
 * agent 角色不强制。
 */
function require_email_verified(): void
{
    $u = current_user();
    if (!$u) {
        return;
    }
    if ($u['role'] === 'customer' && empty($u['email_verified_at'])) {
        header('Location: verify_email.php');
        exit;
    }
}

/**
 * 是否已完成邮箱验证。
 */
function is_email_verified(array $u): bool
{
    return !empty($u['email_verified_at']);
}
