<?php
// qq_send.php — QQ 机器人 OpenAPI 客户端：access_token 缓存、单聊发消息、主动消息额度、状态通知策略
// 严格依据官方文档实现：https://bot.q.qq.com/wiki/develop/api-v2/
declare(strict_types=1);

require_once __DIR__ . '/db.php';

const QQ_API_BASE    = 'https://api.bot.qq.com';
const QQ_TOKEN_URL   = 'https://api.bot.qq.com/app/getAppAccessToken';
const QQ_TOKEN_FILE  = __DIR__ . '/runtime/qq_token.json';

/**
 * 机器人配置：优先读取 settings 表，回退 config.php。
 */
function qq_conf(): array
{
    $c = config()['qq'] ?? [];
    $appId        = (string)setting_get('qq_app_id', $c['app_id'] ?? '');
    $appSecret    = (string)setting_get('qq_app_secret', $c['app_secret'] ?? '');
    $clientSecret = (string)setting_get('qq_client_secret', $c['client_secret'] ?? '');
    if ($clientSecret === '') {
        $clientSecret = $appSecret; // 未单独配置时与 Bot Secret 相同
    }
    return [
        'app_id'        => $appId,
        'app_secret'    => $appSecret,
        'client_secret' => $clientSecret,
    ];
}

function qq_runtime_dir(): string
{
    $dir = __DIR__ . '/runtime';
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }
    return $dir;
}

/**
 * 根据 Bot Secret 生成 Ed25519 种子：secret 循环填充（每次翻倍）至 ≥32 字节后取前 32 字节。
 * 与官方 Go 示例 strings.Repeat(seed, 2) 的行为一致。
 */
function qq_ed25519_seed(string $secret): string
{
    $seed = $secret;
    while (strlen($seed) < 32) {
        $seed .= $seed; // 翻倍
    }
    return substr($seed, 0, 32);
}

/**
 * Ed25519 后端探测：优先 sodium，其次 PHP openssl（OpenSSL 1.1.1+ 支持 Ed25519）。
 * 两者对同一 seed/消息产生完全一致的签名（RFC 8032 确定性签名）。
 *
 * @return string 'sodium' | 'openssl' | 'none'
 */
function qq_ed25519_backend(): string
{
    if (function_exists('sodium_crypto_sign_seed_keypair')) {
        return 'sodium';
    }
    if (function_exists('openssl_pkey_get_private')
        && defined('OPENSSL_VERSION_NUMBER')
        && OPENSSL_VERSION_NUMBER >= 0x10101000) {
        return 'openssl';
    }
    return 'none';
}

/**
 * 由 32 字节 seed 构造 Ed25519 私钥的 PKCS#8(PEM)。
 */
function qq_ed25519_private_pem(string $seed): string
{
    $der = hex2bin('302e020100300506032b657004220420') . $seed;
    return "-----BEGIN PRIVATE KEY-----\n" . chunk_split(base64_encode($der), 64, "\n") . "-----END PRIVATE KEY-----\n";
}

/**
 * 用 Bot Secret 对消息签名，返回 64 字节原始签名。
 */
function qq_ed25519_sign(string $msg, string $secret): string
{
    $seed = qq_ed25519_seed($secret);
    switch (qq_ed25519_backend()) {
        case 'sodium':
            $kp = sodium_crypto_sign_seed_keypair($seed);
            return sodium_crypto_sign_detached($msg, sodium_crypto_sign_secretkey($kp));
        case 'openssl':
            $key = openssl_pkey_get_private(qq_ed25519_private_pem($seed));
            if (!$key) {
                throw new RuntimeException('openssl 无法加载 Ed25519 私钥');
            }
            $sig = '';
            // Ed25519 不指定摘要算法，第 4 参数必须为 0/null（默认 SHA1 会失败）
            if (!openssl_sign($msg, $sig, $key, 0)) {
                throw new RuntimeException('openssl_sign(Ed25519) 失败');
            }
            return $sig;
        default:
            throw new RuntimeException('缺少 sodium 或 OpenSSL(1.1.1+) 扩展，无法生成 Ed25519 签名');
    }
}

/**
 * 用 Bot Secret 派生公钥校验签名。
 */
function qq_ed25519_verify(string $sig, string $msg, string $secret): bool
{
    if (strlen($sig) !== 64) {
        return false;
    }
    $seed = qq_ed25519_seed($secret);
    switch (qq_ed25519_backend()) {
        case 'sodium':
            $kp = sodium_crypto_sign_seed_keypair($seed);
            return sodium_crypto_sign_verify_detached($sig, $msg, sodium_crypto_sign_publickey($kp));
        case 'openssl':
            $key = openssl_pkey_get_private(qq_ed25519_private_pem($seed));
            if (!$key) {
                return false;
            }
            $det = openssl_pkey_get_details($key);
            if (empty($det['key'])) {
                return false;
            }
            return openssl_verify($msg, $sig, $det['key'], 0) === 1;
        default:
            return false;
    }
}

/**
 * 用 Bot Secret 派生 Ed25519 公钥（原始 32 字节），用于自检/诊断。
 */
function qq_ed25519_public_key(string $secret): string
{
    $seed = qq_ed25519_seed($secret);
    switch (qq_ed25519_backend()) {
        case 'sodium':
            $kp = sodium_crypto_sign_seed_keypair($seed);
            return sodium_crypto_sign_publickey($kp);
        case 'openssl':
            $key = openssl_pkey_get_private(qq_ed25519_private_pem($seed));
            if (!$key) {
                return '';
            }
            $det = openssl_pkey_get_details($key);
            if (empty($det['key'])) {
                return '';
            }
            $der = base64_decode(preg_replace('/-----[^-]+-----|\s/', '', $det['key']));
            return substr($der, -32);
        default:
            return '';
    }
}

/**
 * 获取 access_token（服务端文件缓存，过期前 60 秒刷新）。
 * POST https://api.bot.qq.com/app/getAppAccessToken  {appId, clientSecret} -> {access_token, expires_in}
 */
function getAccessToken(bool $force = false): ?string
{
    $conf  = qq_conf();
    $appId = $conf['app_id'];
    if ($appId === '' || $conf['client_secret'] === '') {
        return null;
    }

    if (!$force && is_file(QQ_TOKEN_FILE)) {
        $raw = json_decode((string)@file_get_contents(QQ_TOKEN_FILE), true);
        if (is_array($raw)
            && ($raw['app_id'] ?? '') === $appId
            && !empty($raw['access_token'])
            && (int)($raw['expire_at'] ?? 0) - 60 > time()) {
            return (string)$raw['access_token'];
        }
    }

    $res = qq_http('POST', QQ_TOKEN_URL, [
        'appId'        => $appId,
        'clientSecret' => $conf['client_secret'],
    ], null, false);

    if (!is_array($res['json']) || empty($res['json']['access_token'])) {
        return null;
    }
    $token    = (string)$res['json']['access_token'];
    $expires  = (int)($res['json']['expires_in'] ?? 7200);
    $expireAt = time() + max(60, $expires);

    qq_runtime_dir();
    @file_put_contents(QQ_TOKEN_FILE, json_encode([
        'app_id'       => $appId,
        'access_token' => $token,
        'expire_at'    => $expireAt,
    ]), LOCK_EX);

    return $token;
}

/**
 * 通用 HTTP 请求（cURL）。
 * @param bool $auth 是否附带 Authorization: QQBot {token}
 */
function qq_http(string $method, string $url, ?array $body = null, ?string $token = null, bool $auth = true): array
{
    $headers = ['Content-Type: application/json'];
    if ($auth) {
        $token = $token ?: getAccessToken();
        if (!$token) {
            return ['status' => 0, 'json' => null, 'raw' => '', 'error' => 'no access_token'];
        }
        // 文档规定：Authorization: QQBot ACCESS_TOKEN
        $headers[] = 'Authorization: QQBot ' . $token;
    }

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_CUSTOMREQUEST  => strtoupper($method),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => $headers,
        CURLOPT_TIMEOUT        => 10,
        CURLOPT_CONNECTTIMEOUT => 6,
        CURLOPT_SSL_VERIFYPEER => true,
    ]);
    if ($body !== null) {
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body, JSON_UNESCAPED_UNICODE));
    }
    $raw    = curl_exec($ch);
    $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err    = curl_error($ch);
    curl_close($ch);

    return [
        'status' => $status,
        'json'   => is_string($raw) ? json_decode($raw, true) : null,
        'raw'    => is_string($raw) ? $raw : '',
        'error'  => $err ?: null,
    ];
}

/**
 * 发送单聊文本消息。
 * POST /v2/users/{user_openid}/messages  体 {msg_type:0, content}
 * 被动回复：传 msg_id（来自 C2C_MESSAGE_CREATE 的 d.id，5 分钟有效，配合 msg_seq 防重）
 *           或 event_id（来自事件外层 id，支持 FRIEND_ADD 等），二选一。
 *
 * @return array 接口响应（含 http_status / ok / data / error）
 */
function send_text(string $userOpenid, string $content, ?string $msgId = null, ?string $eventId = null, int $msgSeq = 1): array
{
    $payload = [
        'msg_type' => 0,
        'content'  => $content,
    ];
    if ($msgId) {
        $payload['msg_id']  = $msgId;
        $payload['msg_seq'] = $msgSeq; // 与 msg_id 联合使用，避免重复发送
    } elseif ($eventId) {
        $payload['event_id'] = $eventId; // 与 msg_id 二选一
    }

    $url = QQ_API_BASE . '/v2/users/' . rawurlencode($userOpenid) . '/messages';
    $res = qq_http('POST', $url, $payload);

    $ok = $res['status'] >= 200 && $res['status'] < 300
        && is_array($res['json']) && !isset($res['json']['code']);

    return [
        'ok'          => $ok,
        'http_status' => $res['status'],
        'data'        => $res['json'],
        'error'       => $res['error'] ?: (is_array($res['json']) && isset($res['json']['code'])
            ? ('code ' . $res['json']['code'] . ' ' . ($res['json']['message'] ?? '')) : null),
    ];
}

/**
 * 主动消息额度：读 qq_bindings，跨月重置；达到产品上限（默认 4/月）返回 false。
 */
function can_send_proactive(int $userId): bool
{
    $limit   = (int)(config()['app']['proactive_monthly_limit'] ?? 4);
    $appId   = qq_conf()['app_id'];
    $st      = db()->prepare('SELECT * FROM qq_bindings WHERE user_id = ? AND bot_app_id = ? LIMIT 1');
    $st->execute([$userId, $appId]);
    $b = $st->fetch();
    if (!$b) {
        return false;
    }
    $month = date('Y-m');
    $count = (int)$b['proactive_count_this_month'];
    if (($b['count_reset_month'] ?? '') !== $month) {
        $count = 0;
        db()->prepare('UPDATE qq_bindings SET proactive_count_this_month = 0, count_reset_month = ? WHERE id = ?')
            ->execute([$month, (int)$b['id']]);
    }
    return $count < $limit;
}

/**
 * 主动消息计数 +1（发送成功后调用，含跨月重置）。
 */
function incr_proactive(int $userId): void
{
    $month = date('Y-m');
    $appId = qq_conf()['app_id'];
    db()->prepare(
        'UPDATE qq_bindings
         SET proactive_count_this_month = IF(count_reset_month = ?, proactive_count_this_month + 1, 1),
             count_reset_month = ?
         WHERE user_id = ? AND bot_app_id = ?'
    )->execute([$month, $month, $userId, $appId]);
}

/**
 * 取绑定信息（含 last_msg_id/last_msg_at）。
 */
function qq_binding_of(int $userId): ?array
{
    $appId = qq_conf()['app_id'];
    $st = db()->prepare('SELECT * FROM qq_bindings WHERE user_id = ? AND bot_app_id = ? LIMIT 1');
    $st->execute([$userId, $appId]);
    $row = $st->fetch();
    return $row ?: null;
}

/**
 * 状态变更通知策略：
 *  - processing：优先站内；当月主动已用 < 阈值（默认 2）才额外发主动
 *  - replied  ：优先被动回复（60 分钟内有 msg_id 则带 msg_id）；否则额度允许再发主动；否则站内
 *  - closed   ：优先主动；额度不足降级站内（详情页展示「已完成」横幅）
 *
 * @return array{channel:string, qq_ok:bool, reason:string}
 */
function qq_notify_ticket(int $ticketId, string $newStatus, string $actor = ''): array
{
    $st = db()->prepare('SELECT t.*, u.username AS customer_name FROM tickets t JOIN users u ON u.id = t.user_id WHERE t.id = ? LIMIT 1');
    $st->execute([$ticketId]);
    $t = $st->fetch();
    if (!$t) {
        return ['channel' => 'none', 'qq_ok' => false, 'reason' => 'ticket_not_found'];
    }
    $userId = (int)$t['user_id'];
    $title  = $t['title'];
    $short  = '#T' . str_pad((string)$t['id'], 6, '0', STR_PAD_LEFT);

    $texts = [
        'processing' => "【工单 {$short}】客服已接单，正在处理中：{$title}",
        'replied'    => "【工单 {$short}】客服已回复，请登录工单系统查看：{$title}",
        'closed'     => "【工单 {$short}】已关闭，感谢您的反馈：{$title}",
    ];
    $msg = $texts[$newStatus] ?? "【工单 {$short}】状态更新为 " . status_label($newStatus) . "：{$title}";

    // 始终写站内通知（确保系统内可见）
    add_notification($userId, $ticketId, $msg, 'inner');

    $binding = qq_binding_of($userId);
    if (!$binding) {
        return ['channel' => 'inner', 'qq_ok' => false, 'reason' => 'not_bound'];
    }
    $openid = (string)$binding['qq_user_openid'];

    // 1) replied：优先被动回复
    if ($newStatus === 'replied') {
        $lastAt = $binding['last_msg_at'] ? strtotime((string)$binding['last_msg_at']) : 0;
        if ($binding['last_msg_id'] && $lastAt && (time() - $lastAt) <= 3600) {
            $r = send_text($openid, $msg, (string)$binding['last_msg_id'], null, 1);
            if ($r['ok']) {
                return ['channel' => 'qq_passive', 'qq_ok' => true, 'reason' => 'msg_id'];
            }
        }
    }

    // 2) 额度判断（processing 使用更严格阈值）
    $used      = (int)$binding['proactive_count_this_month'];
    $threshold = (int)(config()['app']['processing_inner_threshold'] ?? 2);
    $allowProactive = can_send_proactive($userId);
    if ($newStatus === 'processing' && $used >= $threshold) {
        $allowProactive = false; // processing 状态收紧，优先站内
    }

    if ($allowProactive) {
        $r = send_text($openid, $msg);
        if ($r['ok']) {
            incr_proactive($userId);
            return ['channel' => 'qq_proactive', 'qq_ok' => true, 'reason' => 'proactive'];
        }
        return ['channel' => 'inner', 'qq_ok' => false, 'reason' => 'qq_error:' . (string)$r['error']];
    }

    return ['channel' => 'inner', 'qq_ok' => false, 'reason' => 'quota_exceeded'];
}
