<?php
// ticket_detail.php — 客户工单详情：左栏信息 + 回复时间线，右栏固定侧边信息卡
declare(strict_types=1);
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';

$u = require_login();
if ($u['role'] === 'agent') {
    header('Location: agent_ticket_detail.php?id=' . (int)($_GET['id'] ?? 0));
    exit;
}
require_email_verified(); // 未验证邮箱 -> verify_email.php

$id = (int)($_GET['id'] ?? 0);
$st = db()->prepare('SELECT t.*, a.username AS agent_name FROM tickets t
                     LEFT JOIN users a ON a.id = t.assigned_agent_id
                     WHERE t.id = ? AND t.user_id = ? LIMIT 1');
$st->execute([$id, (int)$u['id']]);
$t = $st->fetch();
if (!$t) {
    http_response_code(404);
    $PAGE_TITLE = '工单不存在';
    include __DIR__ . '/header.php';
    echo '<div class="card empty">找不到该工单，或无权访问。</div>';
    include __DIR__ . '/footer.php';
    exit;
}

$rs = db()->prepare('SELECT r.*, u.username, u.role, u.avatar_color FROM ticket_replies r
                     LEFT JOIN users u ON u.id = r.user_id
                     WHERE r.ticket_id = ? ORDER BY r.created_at ASC, r.id ASC');
$rs->execute([$id]);
$replies = $rs->fetchAll();

$PAGE_TITLE = '工单 #T' . str_pad((string)$t['id'], 6, '0', STR_PAD_LEFT);
include __DIR__ . '/header.php';
?>
<div class="flex gap8 wrap mb16">
  <a class="tab" href="ticket_list.php">我的工单</a>
  <a class="tab" href="ticket_create.php">创建工单</a>
</div>

<?php if ($t['status'] === 'closed'): ?>
  <div class="banner-done">
    <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="#00e676" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>
    本工单已完成并关闭。如需继续沟通，可在下方追加回复重新打开。
  </div>
<?php endif; ?>

<div class="split">
  <div class="split-left">
    <div class="card">
      <div class="between mb16">
        <h2 class="card-title" style="margin:0"><span class="dot"></span><?= e($t['title']) ?></h2>
        <span class="badge badge-<?= e($t['status']) ?>"><?= e(status_label($t['status'])) ?></span>
      </div>
      <p style="white-space:pre-wrap;margin-top:0"><?= e($t['description']) ?></p>
      <div class="muted mono" style="font-size:12px">UUID <?= e($t['uuid']) ?></div>
    </div>

    <div class="card">
      <h3 class="card-title"><span class="dot"></span>回复时间线</h3>
      <?php if (!$replies): ?>
        <div class="empty">暂无回复</div>
      <?php else: ?>
        <div class="timeline">
          <?php foreach ($replies as $r): ?>
            <?php
              $isAi  = $r['reply_type'] === 'ai';
              $who   = ['agent' => '客服', 'system' => '系统', 'ai' => 'AI 助手'][$r['reply_type']] ?? '客户';
              $name  = $isAi ? 'AI 助手' : (string)($r['username'] ?? '');
              $color = $isAi ? '#7c4dff' : (string)($r['avatar_color'] ?? '#00e5ff');
            ?>
            <div class="timeline-item t-<?= e($r['reply_type']) ?>">
              <span class="timeline-dot"></span>
              <div class="timeline-head">
                <span class="avatar sm" style="background:<?= e($color) ?>"><?= e($isAi ? 'AI' : initial($name)) ?></span>
                <b><?= e($name) ?></b>
                <span class="role-tag"><?= e($who) ?></span>
                <span class="timeline-time"><?= e($r['created_at']) ?></span>
              </div>
              <div class="timeline-body"><?= e($r['content']) ?></div>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>

      <form method="post" action="ticket_reply.php" class="mt24">
        <?= csrf_field() ?>
        <input type="hidden" name="ticket_id" value="<?= (int)$t['id'] ?>">
        <div class="form-group">
          <label for="content">追加回复</label>
          <textarea id="content" name="content" required placeholder="补充说明或继续沟通…"></textarea>
        </div>
        <button class="btn btn-primary" type="submit">提交回复</button>
      </form>
    </div>
  </div>

  <aside class="split-right">
    <div class="card">
      <h3 class="card-title"><span class="dot"></span>工单信息</h3>
      <div class="info-list">
        <div class="info-row"><span class="k">编号</span><span class="v mono">#T<?= str_pad((string)$t['id'], 6, '0', STR_PAD_LEFT) ?></span></div>
        <div class="info-row"><span class="k">状态</span><span class="v"><span class="badge badge-<?= e($t['status']) ?>"><?= e(status_label($t['status'])) ?></span></span></div>
        <div class="info-row"><span class="k">优先级</span><span class="v"><span class="badge badge-<?= e($t['priority']) ?>"><?= e(priority_label($t['priority'])) ?></span></span></div>
        <div class="info-row"><span class="k">处理客服</span><span class="v"><?= $t['agent_name'] ? e($t['agent_name']) : '<span class="muted">未分配</span>' ?></span></div>
        <div class="info-row"><span class="k">创建时间</span><span class="v mono"><?= e($t['created_at']) ?></span></div>
        <div class="info-row"><span class="k">更新时间</span><span class="v mono"><?= e($t['updated_at']) ?></span></div>
      </div>
      <a class="btn btn-ghost btn-block mt16" href="ticket_list.php">返回列表</a>
    </div>

    <?php $b = get_binding((int)$u['id']); ?>
    <div class="card">
      <h3 class="card-title"><span class="dot"></span>通知绑定</h3>
      <div class="info-list">
        <div class="info-row"><span class="k">QQ</span><span class="v"><?= $b ? '已绑定' : '未绑定' ?></span></div>
        <?php if ($b): ?>
          <div class="info-row"><span class="k">本月主动消息</span><span class="v mono"><?= (int)$b['proactive_count_this_month'] ?> / <?= (int)(config()['app']['proactive_monthly_limit'] ?? 4) ?></span></div>
        <?php endif; ?>
      </div>
    </div>
  </aside>
</div>
<?php include __DIR__ . '/footer.php'; ?>
