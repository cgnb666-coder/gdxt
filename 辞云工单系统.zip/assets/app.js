// assets/app.js — 工单系统前端交互（原生 JS，无外部依赖）
(function () {
  'use strict';

  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };

  /* ===== 抽屉（移动端侧边栏）开合 ===== */
  var sidebar = $('#sidebar');
  var overlay = $('#sidebarOverlay');
  var hamburger = $('#hamburger');

  function openDrawer() {
    if (!sidebar) return;
    sidebar.classList.add('open');
    if (overlay) overlay.classList.add('show');
    document.body.style.overflow = 'hidden';
  }
  function closeDrawer() {
    if (!sidebar) return;
    sidebar.classList.remove('open');
    if (overlay) overlay.classList.remove('show');
    document.body.style.overflow = '';
  }
  if (hamburger) hamburger.addEventListener('click', function () {
    sidebar && sidebar.classList.contains('open') ? closeDrawer() : openDrawer();
  });
  if (overlay) overlay.addEventListener('click', closeDrawer);
  $$('.nav-item').forEach(function (a) {
    a.addEventListener('click', function () { if (window.innerWidth < 768) closeDrawer(); });
  });
  window.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeDrawer(); });

  /* ===== 管理员下拉 ===== */
  var adminBtn = $('#adminBtn'), adminMenu = $('#adminMenu');
  if (adminBtn && adminMenu) {
    adminBtn.addEventListener('click', function (e) {
      e.stopPropagation();
      adminMenu.classList.toggle('show');
    });
    document.addEventListener('click', function () { adminMenu.classList.remove('show'); });
  }

  /* ===== 筛选 tab：切换即跳转（带 data-href）或本地高亮 ===== */
  $$('.filter-tabs').forEach(function (bar) {
    $$('.tab', bar).forEach(function (tab) {
      tab.addEventListener('click', function (e) {
        var href = tab.getAttribute('data-href');
        if (href) { window.location.href = href; return; }
        $$('.tab', bar).forEach(function (t) { t.classList.remove('active'); });
        tab.classList.add('active');
      });
    });
  });

  /* ===== 批量选择 ===== */
  var checkAll = $('#checkAll');
  function rowChecks() { return $$('.row-check'); }
  function refreshBulk() {
    var n = rowChecks().filter(function (c) { return c.checked; }).length;
    var btn = $('#bulkBar');
    if (btn) btn.classList.toggle('hide', n === 0);
    var cnt = $('#bulkCount'); if (cnt) cnt.textContent = String(n);
  }
  if (checkAll) {
    checkAll.addEventListener('change', function () {
      rowChecks().forEach(function (c) { c.checked = checkAll.checked; });
      refreshBulk();
    });
  }
  rowChecks().forEach(function (c) { c.addEventListener('change', refreshBulk); });
  refreshBulk();

  /* ===== 简易 toast ===== */
  window.toast = function (msg, type) {
    var t = document.createElement('div');
    t.className = 'toast ' + (type || '');
    t.textContent = msg;
    document.body.appendChild(t);
    requestAnimationFrame(function () { t.classList.add('show'); });
    setTimeout(function () { t.classList.remove('show'); setTimeout(function () { t.remove(); }, 300); }, 2600);
  };

  /* ===== 复制到剪贴板 ===== */
  $$('[data-copy]').forEach(function (el) {
    el.addEventListener('click', function () {
      var text = el.getAttribute('data-copy');
      var done = function () { window.toast('已复制到剪贴板', 'ok'); };
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(done, function () { window.toast('复制失败，请手动复制', 'err'); });
      } else {
        var ta = document.createElement('textarea');
        ta.value = text; document.body.appendChild(ta); ta.select();
        try { document.execCommand('copy'); done(); } catch (e) { window.toast('复制失败', 'err'); }
        ta.remove();
      }
    });
  });

  /* ===== 绑定状态轮询（仅在绑定页启用）===== */
  var pollEl = $('#bindPoll');
  if (pollEl) {
    var url = pollEl.getAttribute('data-check-url') || 'check_binding.php';
    var target = pollEl.getAttribute('data-redirect') || 'ticket_list.php';
    var stopped = false;
    function poll() {
      if (stopped) return;
      fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
        .then(function (r) { return r.json(); })
        .then(function (d) {
          if (d && d.bound) {
            stopped = true;
            window.toast('绑定成功，正在进入工单系统…', 'ok');
            setTimeout(function () { window.location.href = target; }, 800);
            return;
          }
          setTimeout(poll, 3000);
        })
        .catch(function () { setTimeout(poll, 4000); });
    }
    setTimeout(poll, 3000);
  }

  /* ===== 数据库连接测试（安装向导）===== */
  var testBtn = $('#testDbBtn');
  if (testBtn) {
    testBtn.addEventListener('click', function () {
      var form = $('#dbForm');
      if (!form) return;
      var box = $('#testDbResult');
      testBtn.disabled = true; testBtn.textContent = '测试中…';
      var fd = new FormData(form); fd.set('action', 'test_db');
      fetch('install.php', { method: 'POST', body: fd })
        .then(function (r) { return r.json(); })
        .then(function (d) {
          box.className = 'alert ' + (d.ok ? 'alert-success' : 'alert-danger');
          box.textContent = d.message || (d.ok ? '连接成功' : '连接失败');
          box.classList.remove('hide');
        })
        .catch(function () {
          box.className = 'alert alert-danger'; box.textContent = '请求失败，请检查服务器。'; box.classList.remove('hide');
        })
        .finally(function () { testBtn.disabled = false; testBtn.textContent = '测试连接'; });
    });
  }

  /* ===== 危险操作二次确认 ===== */
  $$('[data-confirm]').forEach(function (el) {
    el.addEventListener('click', function (e) {
      if (!window.confirm(el.getAttribute('data-confirm'))) e.preventDefault();
    });
  });
})();
