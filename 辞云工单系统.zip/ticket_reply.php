<?php
// ticket_reply.php — 追加回复（客户 / 客服共用）：写回复、联动状态、通知客户与管理员（QQ + 邮件）
declare(strict_types=1);
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/qq_send.php';
require_once __DIR__ . '/mailer.php';

$u = require_login();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ticket_list.php');
    exit;
}
csrf_check();

$ticketId = (int)($_POST['ticket_id'] ?? 0);
$content  = trim((string)($_POST['content'] ?? ''));

if ($ticketId <= 0 || $content === '') {
    flash_set('danger', '回复内容不能为空。');
    header('Location: ticket_detail.php?id=' . $ticketId);
    exit;
}

$st = db()->prepare('SELECT * FROM tickets WHERE id = ? LIMIT 1');
$st->execute([$ticketId]);
$t = $st->fetch();
if (!$t) {
    flash_set('danger', '工单不存在。');
    header('Location: ticket_list.php');
    exit;
}

if ($u['role'] === 'agent') {
    // 客服回复
    db()->prepare('INSERT INTO ticket_replies (ticket_id, user_id, content, reply_type, created_at)
                   VALUES (?, ?, ?, "agent", NOW())')
        ->execute([$ticketId, (int)$u['id'], $content]);

    $assign = $t['assigned_agent_id'] ?: (int)$u['id'];
    db()->prepare('UPDATE tickets SET status = "replied", assigned_agent_id = ?, updated_at = NOW() WHERE id = ?')
        ->execute([$assign, $ticketId]);

    flash_set('success', '回复已发送，工单状态更新为「已回复」。');
    qq_notify_ticket($ticketId, 'replied', (string)$u['username']);
    email_notify_ticket($ticketId, 'agent_reply', (string)$u['username']);
    header('Location: agent_ticket_detail.php?id=' . $ticketId);
    exit;
}

// 客户回复：必须拥有该工单且已通过邮箱验证
require_email_verified();
if ((int)$t['user_id'] !== (int)$u['id']) {
    flash_set('danger', '无权回复该工单。');
    header('Location: ticket_list.php');
    exit;
}

db()->prepare('INSERT INTO ticket_replies (ticket_id, user_id, content, reply_type, created_at)
               VALUES (?, ?, ?, "customer", NOW())')
    ->execute([$ticketId, (int)$u['id'], $content]);

// 客户追加回复：已回复/已关闭 -> 重新打开待处理；处理中保持
$newStatus = in_array($t['status'], ['replied', 'closed'], true) ? 'open' : $t['status'];
db()->prepare('UPDATE tickets SET status = ?, updated_at = NOW() WHERE id = ?')
    ->execute([$newStatus, $ticketId]);

// 通知管理员：客户追加了回复
email_notify_ticket($ticketId, 'customer_reply', (string)$u['username']);

flash_set('success', '回复已提交。');
header('Location: ticket_detail.php?id=' . $ticketId);
exit;
