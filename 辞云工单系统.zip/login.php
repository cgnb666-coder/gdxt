<?php
// login.php — 登录（按角色跳转：客服->仪表盘；客户->工单列表/绑定引导）
declare(strict_types=1);
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';

if (current_user()) {
    $__cu = current_user();
    if ($__cu['role'] === 'agent') {
        header('Location: agent_dashboard.php');
    } elseif (empty($__cu['email_verified_at'])) {
        header('Location: verify_email.php');
    } else {
        header('Location: ticket_list.php');
    }
    exit;
}

$errors = [];
$old = '';
$next = (string)($_GET['next'] ?? '');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $old  = trim((string)($_POST['account'] ?? ''));
    $pass = (string)($_POST['password'] ?? '');
    $next = (string)($_POST['next'] ?? '');

    if ($old === '' || $pass === '') {
        $errors[] = '请输入账号与密码。';
    } else {
        $st = db()->prepare('SELECT * FROM users WHERE email = ? OR username = ? LIMIT 1');
        $st->execute([$old, $old]);
        $u = $st->fetch();
        if (!$u || !password_verify($pass, (string)$u['password_hash'])) {
            $errors[] = '账号或密码不正确。';
        } else {
            session_regenerate_id(true);
            $_SESSION['uid'] = (int)$u['id'];
            if ($u['role'] === 'agent') {
                header('Location: ' . ($next !== '' ? $next : 'agent_dashboard.php'));
            } elseif (empty($u['email_verified_at'])) {
                header('Location: verify_email.php');
            } else {
                header('Location: ' . ($next !== '' ? $next : 'ticket_list.php'));
            }
            exit;
        }
    }
}

$PAGE_TITLE = '登录';
include __DIR__ . '/header.php';
?>
<div class="auth-wrap">
  <div class="card">
    <h1>登录</h1>
    <p class="muted mb16">欢迎回到工单系统。</p>

    <?php foreach ($errors as $err): ?>
      <div class="alert alert-danger"><?= e($err) ?></div>
    <?php endforeach; ?>

    <form method="post" novalidate>
      <?= csrf_field() ?>
      <input type="hidden" name="next" value="<?= e($next) ?>">
      <div class="form-group">
        <label for="account">邮箱 / 用户名</label>
        <input id="account" name="account" type="text" required value="<?= e($old) ?>" placeholder="请输入邮箱或用户名" autofocus>
      </div>
      <div class="form-group">
        <label for="password">密码</label>
        <input id="password" name="password" type="password" required placeholder="请输入密码">
      </div>
      <button class="btn btn-primary btn-block" type="submit">登录</button>
    </form>
    <p class="muted center mt16">还没有账号？<a href="register.php">立即注册</a></p>
  </div>
</div>
<?php include __DIR__ . '/footer.php'; ?>
