<?php
// callback.php — QQ 机器人回调入口（官方文档最简形态）
// 与 qq_webhook.php 完全等价，仅提供一个更"干净"的回调地址：
//   https://你的域名/callback.php
// 平台对回调地址的要求（官方 event-emit）：必须 HTTPS，端口仅允许 80 / 443 / 8080 / 8443。
// 处理逻辑（op=13 回调验证、Ed25519 签名校验、FRIEND_ADD 绑定、C2C 消息记录）全部在 qq_webhook.php。
require __DIR__ . '/qq_webhook.php';
