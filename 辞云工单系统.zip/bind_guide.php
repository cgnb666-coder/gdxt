<?php
// bind_guide.php — QQ 通知绑定（可选）：绑定后工单状态变更会通过 QQ 机器人推送。
// 注意：本页不再强制，客户可跳过；业务功能的使用门槛是「邮箱验证」。
declare(strict_types=1);
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';

$u = require_login();
if ($u['role'] === 'agent') {
    header('Location: agent_dashboard.php');
    exit;
}

$appId    = (string)setting_get('qq_app_id', config()['qq']['app_id'] ?? '');
$uid      = (int)$u['id'];
$callback = 'uid:' . $uid;
$bound    = is_bound($uid);
$binding  = $bound ? get_binding($uid) : null;

// 开发者分享链接（scene=2003/2004），携带 callback_data 供 FRIEND_ADD 事件回传
$addLink = $appId !== ''
    ? 'https://qun.qq.com/qunpro/robot/share?robot_appid=' . rawurlencode($appId)
      . '&biz_type=0&biz_id=&callback_data=' . rawurlencode($callback)
    : '';

$PAGE_TITLE = 'QQ 通知绑定';
$PAGE_LEAD  = '可选：绑定后工单状态变更会通过 QQ 机器人推送';
include __DIR__ . '/header.php';
?>
<div class="card" id="bindPoll"
     data-check-url="check_binding.php"
     data-redirect="ticket_list.php">
  <div class="bind-grid">
    <div>
      <div class="qr-box">
        <?php if ($addLink): ?>
          <div>
            <div class="muted mb8">扫码 / 复制链接添加机器人</div>
            <div class="mono"><?= e($addLink) ?></div>
          </div>
        <?php else: ?>
          <div>尚未配置机器人 AppID<br>请管理员在「系统设置」中填写后再绑定</div>
        <?php endif; ?>
      </div>
    </div>
    <div>
      <h1 style="margin-top:0">绑定 QQ 接收通知</h1>

      <?php if ($bound): ?>
        <div class="alert alert-success">
          已完成绑定（QQ openid：<span class="mono"><?= e($binding['qq_user_openid'] ?? '') ?></span>）。
        </div>
        <p class="muted">工单状态变更将通过 QQ 机器人推送给你。</p>
        <div class="flex gap8 wrap mt8">
          <a class="btn btn-primary" href="ticket_list.php">返回我的工单</a>
        </div>
      <?php else: ?>
        <p class="muted">绑定为<strong>可选</strong>操作，绑定后工单状态变更会通过 QQ 机器人推送。即使不绑定，你也可以正常创建与查看工单。</p>

        <div class="alert alert-info">
          当前绑定标识：<span class="mono">callback_data = <?= e($callback) ?></span>
        </div>

        <ol class="muted" style="padding-left:20px;line-height:2">
          <li>用手机 QQ 打开下方添加链接（或复制到 QQ 打开）。</li>
          <li>点击「添加」把机器人加入消息列表。</li>
          <li>保持本页打开，系统每 3 秒自动检测绑定状态。</li>
        </ol>

        <?php if ($addLink): ?>
          <div class="flex gap8 wrap mt8">
            <a class="btn btn-primary" href="<?= e($addLink) ?>" target="_blank" rel="noopener">打开添加链接</a>
            <button class="btn btn-ghost" type="button" data-copy="<?= e($addLink) ?>">复制链接</button>
            <a class="btn btn-ghost" href="ticket_list.php">跳过，暂不绑定</a>
          </div>
        <?php else: ?>
          <div class="alert alert-warn">机器人未配置，请联系管理员在系统设置中填写 AppID / AppSecret。</div>
        <?php endif; ?>

        <p class="mt16"><span class="pulse-dot"></span> <span class="muted">等待绑定中…</span></p>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php include __DIR__ . '/footer.php'; ?>
