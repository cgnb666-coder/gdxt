<?php
// agent_ticket_detail.php — 客服工单详情：左栏信息 + 时间线，右栏固定侧边信息卡与操作
declare(strict_types=1);
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/ai.php';

$u = require_agent();
$id = (int)($_GET['id'] ?? 0);

$st = db()->prepare('SELECT t.*, u.username AS customer_name, u.email AS customer_email,
                            a.username AS agent_name
                     FROM tickets t
                     JOIN users u ON u.id = t.user_id
                     LEFT JOIN users a ON a.id = t.assigned_agent_id
                     WHERE t.id = ? LIMIT 1');
$st->execute([$id]);
$t = $st->fetch();
if (!$t) {
    flash_set('danger', '工单不存在。');
    header('Location: agent_tickets.php');
    exit;
}

$rs = db()->prepare('SELECT r.*, u.username, u.role, u.avatar_color FROM ticket_replies r
                     LEFT JOIN users u ON u.id = r.user_id
                     WHERE r.ticket_id = ? ORDER BY r.created_at ASC, r.id ASC');
$rs->execute([$id]);
$replies = $rs->fetchAll();

$ns = db()->prepare('SELECT * FROM notifications WHERE ticket_id = ? ORDER BY id DESC LIMIT 6');
$ns->execute([$id]);
$notices = $ns->fetchAll();

$back = 'agent_ticket_detail.php?id=' . $id;

$IS_AGENT_LAYOUT = true;
$ACTIVE_MENU     = 'tickets';
$PAGE_TITLE      = '工单 #T' . str_pad((string)$t['id'], 6, '0', STR_PAD_LEFT);
$BREADCRUMB      = ['工单管理', '工单详情', '#T' . str_pad((string)$t['id'], 6, '0', STR_PAD_LEFT)];
include __DIR__ . '/header.php';
?>
<div class="split">
  <div class="split-left">
    <div class="card">
      <div class="between mb16">
        <h2 class="card-title" style="margin:0"><span class="dot"></span><?= e($t['title']) ?></h2>
        <span class="badge badge-<?= e($t['status']) ?>"><?= e(status_label($t['status'])) ?></span>
      </div>
      <p style="white-space:pre-wrap;margin-top:0"><?= e($t['description']) ?></p>
      <div class="muted mono" style="font-size:12px">UUID <?= e($t['uuid']) ?></div>
    </div>

    <div class="card">
      <h3 class="card-title"><span class="dot"></span>沟通时间线</h3>
      <?php if (!$replies): ?>
        <div class="empty">暂无往来记录</div>
      <?php else: ?>
        <div class="timeline">
          <?php foreach ($replies as $r): ?>
            <?php
              $isAi  = $r['reply_type'] === 'ai';
              $who   = ['agent' => '客服', 'system' => '系统', 'ai' => 'AI 助手'][$r['reply_type']] ?? '客户';
              $name  = $isAi ? 'AI 助手' : (string)($r['username'] ?? '');
              $color = $isAi ? '#7c4dff' : (string)($r['avatar_color'] ?? '#00e5ff');
            ?>
            <div class="timeline-item t-<?= e($r['reply_type']) ?>">
              <span class="timeline-dot"></span>
              <div class="timeline-head">
                <span class="avatar sm" style="background:<?= e($color) ?>"><?= e($isAi ? 'AI' : initial($name)) ?></span>
                <b><?= e($name) ?></b>
                <span class="role-tag"><?= e($who) ?></span>
                <span class="timeline-time"><?= e($r['created_at']) ?></span>
              </div>
              <div class="timeline-body"><?= e($r['content']) ?></div>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>

      <form method="post" action="ticket_reply.php" class="mt24" id="replyForm">
        <?= csrf_field() ?>
        <input type="hidden" name="ticket_id" value="<?= (int)$t['id'] ?>">
        <div class="form-group">
          <label for="content">回复客户</label>
          <textarea id="content" name="content" required placeholder="输入回复内容，提交后工单状态将变为「已回复」并通知客户…"></textarea>
        </div>
        <div class="flex gap8 wrap">
          <button class="btn btn-primary" type="submit">发送回复</button>
          <?php if (ai_enabled()): ?>
            <button class="btn btn-ghost" type="button" id="aiGenBtn" data-id="<?= (int)$t['id'] ?>">AI 生成回复</button>
          <?php endif; ?>
        </div>
      </form>
    </div>
  </div>

  <aside class="split-right">
    <div class="card">
      <h3 class="card-title"><span class="dot"></span>客户信息</h3>
      <div class="info-list">
        <div class="info-row"><span class="k">用户名</span><span class="v"><?= e($t['customer_name']) ?></span></div>
        <div class="info-row"><span class="k">邮箱</span><span class="v"><?= e($t['customer_email']) ?></span></div>
      </div>
    </div>

    <div class="card">
      <h3 class="card-title"><span class="dot"></span>工单信息</h3>
      <div class="info-list">
        <div class="info-row"><span class="k">编号</span><span class="v mono">#T<?= str_pad((string)$t['id'], 6, '0', STR_PAD_LEFT) ?></span></div>
        <div class="info-row"><span class="k">状态</span><span class="v"><span class="badge badge-<?= e($t['status']) ?>"><?= e(status_label($t['status'])) ?></span></span></div>
        <div class="info-row"><span class="k">优先级</span><span class="v"><span class="badge badge-<?= e($t['priority']) ?>"><?= e(priority_label($t['priority'])) ?></span></span></div>
        <div class="info-row"><span class="k">处理客服</span><span class="v"><?= $t['agent_name'] ? e($t['agent_name']) : '<span class="muted">未分配</span>' ?></span></div>
        <div class="info-row"><span class="k">创建时间</span><span class="v mono"><?= e($t['created_at']) ?></span></div>
        <div class="info-row"><span class="k">更新时间</span><span class="v mono"><?= e($t['updated_at']) ?></span></div>
      </div>

      <div class="flex gap8 wrap mt16">
        <?php if ($t['status'] === 'open'): ?>
          <a class="btn btn-primary btn-block" href="ticket_status.php?ticket_id=<?= (int)$t['id'] ?>&action=accept&back=<?= urlencode($back) ?>">接单处理</a>
        <?php endif; ?>
        <?php if ($t['status'] !== 'closed'): ?>
          <a class="btn btn-danger btn-block" href="ticket_status.php?ticket_id=<?= (int)$t['id'] ?>&action=close&back=<?= urlencode($back) ?>"
             data-confirm="确定关闭该工单？客户将收到已完成通知。">关闭工单</a>
        <?php else: ?>
          <a class="btn btn-ghost btn-block" href="ticket_status.php?ticket_id=<?= (int)$t['id'] ?>&action=accept&back=<?= urlencode($back) ?>">重新打开</a>
        <?php endif; ?>
        <a class="btn btn-ghost btn-block" href="agent_tickets.php">返回列表</a>
      </div>
    </div>

    <div class="card">
      <h3 class="card-title"><span class="dot"></span>通知记录</h3>
      <?php if (!$notices): ?>
        <div class="muted">暂无通知</div>
      <?php else: ?>
        <div class="info-list">
          <?php foreach ($notices as $n): ?>
            <div class="info-row">
              <span class="k"><?= e($n['channel']) ?></span>
              <span class="v muted" style="font-size:12.5px"><?= e($n['content']) ?></span>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>
  </aside>
</div>

<?php if (ai_enabled()): ?>
<script>
// 「AI 生成回复」：调用后端生成建议并填入回复框，人工确认后再发送
(function () {
  var btn = document.getElementById('aiGenBtn');
  if (!btn) return;
  btn.addEventListener('click', function () {
    var ta = document.getElementById('content');
    var old = btn.textContent;
    btn.disabled = true;
    btn.textContent = 'AI 生成中…';
    fetch('ai_reply.php?id=' + encodeURIComponent(btn.dataset.id), { credentials: 'same-origin' })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        if (d && d.ok) {
          ta.value = d.reply;
          ta.focus();
        } else {
          alert('AI 生成失败：' + (d && d.error ? d.error : '未知错误'));
        }
      })
      .catch(function () { alert('AI 生成失败：网络错误'); })
      .then(function () { btn.disabled = false; btn.textContent = old; });
  });
})();
</script>
<?php endif; ?>
<?php include __DIR__ . '/footer.php'; ?>
