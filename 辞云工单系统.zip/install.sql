-- install.sql — 工单系统数据库结构（MySQL / utf8mb4）
SET NAMES utf8mb4;

-- 用户表
CREATE TABLE IF NOT EXISTS users (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  username      VARCHAR(64)  NOT NULL,
  email         VARCHAR(190) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role          ENUM('customer','agent') NOT NULL DEFAULT 'customer',
  avatar_color  VARCHAR(16)  NOT NULL DEFAULT '#00e5ff',
  -- 邮箱绑定（验证）：未验证的客户无法使用业务功能
  email_verified_at DATETIME NULL DEFAULT NULL,
  verify_code       VARCHAR(12) NULL DEFAULT NULL,
  verify_expires    DATETIME NULL DEFAULT NULL,
  created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uniq_email (email),
  KEY idx_role (role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- QQ 绑定表（唯一键：(bot_app_id, qq_user_openid) 与 (user_id, bot_app_id)）
CREATE TABLE IF NOT EXISTS qq_bindings (
  id                        INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id                   INT UNSIGNED NOT NULL,
  bot_app_id                VARCHAR(64)  NOT NULL,
  qq_user_openid            VARCHAR(128) NOT NULL,
  bound_at                  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  proactive_count_this_month TINYINT UNSIGNED NOT NULL DEFAULT 0,
  count_reset_month         CHAR(7)      NOT NULL DEFAULT '',
  -- 最近一次来自该用户的 C2C_MESSAGE_CREATE 的 d.id 与时间（60 分钟内可被动回复）
  last_msg_id               VARCHAR(128) NULL DEFAULT NULL,
  last_msg_at               DATETIME     NULL DEFAULT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uniq_bot_openid (bot_app_id, qq_user_openid),
  UNIQUE KEY uniq_user_bot (user_id, bot_app_id),
  KEY idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 工单表
CREATE TABLE IF NOT EXISTS tickets (
  id                INT UNSIGNED NOT NULL AUTO_INCREMENT,
  uuid              CHAR(36)     NOT NULL,
  user_id           INT UNSIGNED NOT NULL,
  title             VARCHAR(200) NOT NULL,
  description       TEXT         NOT NULL,
  status            ENUM('open','processing','replied','closed') NOT NULL DEFAULT 'open',
  priority          ENUM('low','normal','high') NOT NULL DEFAULT 'normal',
  assigned_agent_id INT UNSIGNED NULL DEFAULT NULL,
  created_at        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uniq_uuid (uuid),
  KEY idx_status (status),
  KEY idx_user (user_id),
  KEY idx_agent (assigned_agent_id),
  KEY idx_updated (updated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 工单回复表
CREATE TABLE IF NOT EXISTS ticket_replies (
  id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  ticket_id  INT UNSIGNED NOT NULL,
  user_id    INT UNSIGNED NOT NULL,
  content    TEXT         NOT NULL,
  reply_type ENUM('customer','agent','system','ai') NOT NULL DEFAULT 'customer',
  created_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_ticket (ticket_id),
  KEY idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 系统设置表（键值对：QQ AppID/Secret、公司名等）
CREATE TABLE IF NOT EXISTS settings (
  k VARCHAR(64) NOT NULL,
  v TEXT        NULL,
  PRIMARY KEY (k)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 站内通知表（主动消息额度不足时的降级通道）
CREATE TABLE IF NOT EXISTS notifications (
  id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id    INT UNSIGNED NOT NULL,
  ticket_id  INT UNSIGNED NULL DEFAULT NULL,
  content    VARCHAR(500) NOT NULL,
  channel    ENUM('inner','qq') NOT NULL DEFAULT 'inner',
  is_read    TINYINT UNSIGNED NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_user_read (user_id, is_read)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
