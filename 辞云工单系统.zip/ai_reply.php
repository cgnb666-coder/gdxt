<?php
// ai_reply.php — 客服端调用：根据工单内容生成 AI 回复建议（返回 JSON，不写库）
declare(strict_types=1);
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/ai.php';

$u = current_user();
if (!$u || $u['role'] !== 'agent') {
    json_out(['ok' => false, 'error' => '未授权'], 403);
}

$id  = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$err = null;
$text = ai_generate_ticket_reply($id, $err);
if ($text === '') {
    json_out(['ok' => false, 'error' => $err ?: '生成失败'], 502);
}
json_out(['ok' => true, 'reply' => $text]);
