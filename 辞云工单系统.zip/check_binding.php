<?php
// check_binding.php — 返回当前用户 QQ 绑定状态的 JSON（供绑定页轮询）
declare(strict_types=1);
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';

$u = current_user();
if (!$u) {
    json_out(['bound' => false, 'error' => 'not_logged_in'], 200);
}

$bound = is_bound((int)$u['id']);
$b     = $bound ? get_binding((int)$u['id']) : null;

json_out([
    'bound'    => $bound,
    'bound_at' => $b['bound_at'] ?? null,
]);
