<?php
// config.sample.php — 配置样例。install.php 会参考此结构生成 config.php
// 实际运行时读取的是 config.php（由安装向导写入），本文件仅作参考/模板。
return [
    'db' => [
        'host'    => '127.0.0.1',
        'port'    => 3306,
        'name'    => 'ticket_system',
        'user'    => 'root',
        'pass'    => '',
        'charset' => 'utf8mb4',
    ],
    'qq' => [
        // 开放平台「机器人」AppID
        'app_id'        => '',
        // Bot Secret / ClientSecret：既用于换取 access_token，也用于 Ed25519 签名
        'app_secret'    => '',
        'client_secret' => '',
    ],
    // 邮件服务（SMTP）：用于发送邮箱验证码。可在后台「系统设置 → 邮件服务」覆盖。
    'mail' => [
        'enabled'   => false,
        'host'      => '',      // 如 smtp.qq.com
        'port'      => 465,
        'secure'    => 'ssl',   // ssl | tls | none
        'user'      => '',      // SMTP 账号（完整邮箱）
        'pass'      => '',      // 密码 / 授权码
        'from'      => '',      // 发件邮箱（一般与 user 相同）
        'from_name' => '',      // 发件人名称
    ],
    // AI 客服（OpenAI 兼容接口）：可在后台「系统设置 → AI 客服设置」覆盖。
    'ai' => [
        'enabled'       => false,
        'base_url'      => '',  // 如 https://api.deepseek.com/v1
        'api_key'       => '',
        'model'         => '',  // 如 deepseek-chat
        'temperature'   => 0.3,
        'max_tokens'    => 800,
        'auto_reply'    => false,
        'signature'     => '',  // 自动回复署名
        'system_prompt' => '',  // 留空则使用内置客服提示词
    ],
    'app' => [
        'name'     => '工单系统',
        'company'  => '示例科技有限公司',
        // 站点根地址（不含结尾斜杠），用于生成回调/跳转链接，留空则自动推断
        'base_url' => '',
        // 单聊主动消息每用户每月的产品级上限（文档原始频控更宽松，这里自行收紧为 4）
        'proactive_monthly_limit' => 4,
        // processing 状态下，当月主动消息已用低于该值才走主动推送
        'processing_inner_threshold' => 2,
    ],
];
