<?php
// ticket_create.php — 客户创建工单（需已验证邮箱）
declare(strict_types=1);
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/mailer.php';
require_once __DIR__ . '/ai.php';

$u = require_login();
if ($u['role'] === 'agent') {
    header('Location: agent_tickets.php');
    exit;
}
require_email_verified(); // 未验证邮箱 -> verify_email.php

$errors = [];
$old = ['title' => '', 'description' => '', 'priority' => 'normal'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $old['title']       = trim((string)($_POST['title'] ?? ''));
    $old['description'] = trim((string)($_POST['description'] ?? ''));
    $old['priority']    = (string)($_POST['priority'] ?? 'normal');

    if ($old['title'] === '' || mb_strlen($old['title']) < 3) {
        $errors[] = '标题至少 3 个字符。';
    }
    if ($old['description'] === '') {
        $errors[] = '请填写问题描述。';
    }
    if (!in_array($old['priority'], ['low', 'normal', 'high'], true)) {
        $old['priority'] = 'normal';
    }

    if (!$errors) {
        $uuid = uuid4();
        $st = db()->prepare('INSERT INTO tickets (uuid, user_id, title, description, status, priority, created_at, updated_at)
                             VALUES (?, ?, ?, ?, "open", ?, NOW(), NOW())');
        $st->execute([$uuid, (int)$u['id'], $old['title'], $old['description'], $old['priority']]);
        $id = (int)db()->lastInsertId();

        // 系统回复，便于时间线展示
        db()->prepare('INSERT INTO ticket_replies (ticket_id, user_id, content, reply_type, created_at)
                       VALUES (?, ?, ?, "system", NOW())')
            ->execute([$id, (int)$u['id'], '工单已提交，客服会尽快处理。']);

        // AI 自动回复（在后台「AI 客服设置」中开启后生效）
        if (ai_conf()['auto_reply'] && ai_enabled()) {
            $aiErr  = null;
            $aiText = ai_generate_ticket_reply($id, $aiErr);
            if ($aiText !== '') {
                ai_save_reply($id, $aiText);
                db()->prepare('UPDATE tickets SET status = "replied", updated_at = NOW() WHERE id = ?')->execute([$id]);
            }
        }

        // 邮件通知：客户收到提交确认，管理员收到新工单提醒
        email_notify_ticket($id, 'created', (string)$u['username']);

        flash_set('success', '工单提交成功，编号 #T' . str_pad((string)$id, 6, '0', STR_PAD_LEFT));
        header('Location: ticket_detail.php?id=' . $id);
        exit;
    }
}

$PAGE_TITLE = '创建工单';
include __DIR__ . '/header.php';
?>
<div class="flex gap8 wrap mb16">
  <a class="tab" href="ticket_list.php">我的工单</a>
  <a class="tab active" href="ticket_create.php">创建工单</a>
</div>

<div class="card" style="max-width:760px">
  <?php foreach ($errors as $err): ?>
    <div class="alert alert-danger"><?= e($err) ?></div>
  <?php endforeach; ?>

  <form method="post" novalidate>
    <?= csrf_field() ?>
    <div class="form-group">
      <label for="title">标题</label>
      <input id="title" name="title" type="text" required maxlength="200"
             value="<?= e($old['title']) ?>" placeholder="简要描述你的问题（至少 3 个字符）">
    </div>
    <div class="form-group">
      <label for="priority">优先级</label>
      <select id="priority" name="priority">
        <option value="low"    <?= $old['priority'] === 'low' ? 'selected' : '' ?>>低</option>
        <option value="normal" <?= $old['priority'] === 'normal' ? 'selected' : '' ?>>中</option>
        <option value="high"   <?= $old['priority'] === 'high' ? 'selected' : '' ?>>高</option>
      </select>
    </div>
    <div class="form-group">
      <label for="description">问题描述</label>
      <textarea id="description" name="description" required
                placeholder="请详细描述遇到的情况、报错信息、复现步骤…"><?= e($old['description']) ?></textarea>
    </div>
    <div class="flex gap8">
      <button class="btn btn-primary" type="submit">提交工单</button>
      <a class="btn btn-ghost" href="ticket_list.php">取消</a>
    </div>
  </form>
</div>
<?php include __DIR__ . '/footer.php'; ?>
