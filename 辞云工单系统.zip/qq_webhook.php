<?php
// qq_webhook.php — QQ 机器人事件回调入口：op=13 回调地址验证（最高优先级）、Ed25519 签名校验、
//                 FRIEND_ADD 绑定、C2C 消息记录。
// 依据：https://bot.q.qq.com/wiki/develop/api-v2/dev-prepare/interface-framework/sign.html
//       https://bot.q.qq.com/wiki/develop/api-v2/server-inter/user/manage/event.html
declare(strict_types=1);

// 回调响应必须是「纯 JSON」：任何 PHP 警告/Notice/Fatal 文本混入都会让平台判为“签名校验不通过”。
// 因此这里关闭错误回显，并开启输出缓冲，最后在 qq_wrap() 里丢弃缓冲，保证响应体干净。
@ini_set('display_errors', '0');
@ini_set('log_errors', '1');
error_reporting(E_ALL);
ob_start();

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/qq_send.php';

// 原始请求体：必须原样读取，签名校验依赖它（勿依赖 $_POST）
$rawBody = file_get_contents('php://input');
if ($rawBody === false) {
    $rawBody = '';
}

/* ===================== 临时调试日志（排查完成后可整段删除） ===================== */
/**
 * 追加写日志到 runtime/qq_webhook.log。
 */
function qq_log(string $tag, $data): void
{
    $dir = __DIR__ . '/runtime';
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }
    $text = is_string($data) ? $data : json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    @file_put_contents(
        $dir . '/qq_webhook.log',
        '[' . date('Y-m-d H:i:s') . '] ' . $tag . ' ' . $text . PHP_EOL,
        FILE_APPEND | LOCK_EX
    );
}

/**
 * 统一响应：先记日志，再输出 JSON。
 */
function qq_wrap($data, int $code = 200): void
{
    $out = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    qq_log('RESPONSE', ['http_status' => $code, 'body' => $out]);
    // 丢弃之前可能产生的任何输出（警告/BOM），确保响应体只包含这段 JSON
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo $out;
    exit;
}
/* ================================ 临时日志结束 ================================ */

$sigHeader = $_SERVER['HTTP_X_SIGNATURE_ED25519'] ?? '';
$tsHeader  = $_SERVER['HTTP_X_SIGNATURE_TIMESTAMP'] ?? '';

// 记录入站请求（body_len 可帮助判断 Nginx 是否把原始请求体透传过来）
qq_log('REQUEST', [
    'method'       => $_SERVER['REQUEST_METHOD'] ?? '',
    'uri'          => $_SERVER['REQUEST_URI'] ?? '',
    'content_type' => $_SERVER['CONTENT_TYPE'] ?? '',
    'body_len'     => strlen($rawBody),
    'sig_ed25519'  => $sigHeader,
    'sig_ts'       => $tsHeader,
]);
qq_log('REQUEST_BODY', $rawBody);

/* 读取配置：settings 表优先，回退 config.php。
 * 注意：config.php 不存在时不能调用 config()（它会 302 到 install.php），否则平台拿到 3xx 会判失败。 */
$conf = [];
if (is_file(__DIR__ . '/config.php')) {
    try {
        $conf = qq_conf();
    } catch (Throwable $e) {
        qq_log('CONF_ERROR', $e->getMessage());
        try {
            $c = config()['qq'] ?? [];
        } catch (Throwable $e2) {
            $c = [];
        }
        $conf = [
            'app_id'        => (string)($c['app_id'] ?? ''),
            'app_secret'    => (string)($c['app_secret'] ?? ''),
            'client_secret' => (string)($c['client_secret'] ?? ($c['app_secret'] ?? '')),
        ];
    }
}
$secret = (string)($conf['app_secret'] ?? '');
qq_log('CRYPTO', ['backend' => qq_ed25519_backend(), 'secret_len' => strlen($secret)]);

/* GET 自检：浏览器直接打开本回调地址即可确认「可达 + 后端可用 + 密钥已配置」 */
if (strtoupper($_SERVER['REQUEST_METHOD'] ?? '') === 'GET') {
    $info = [
        'ok'                => true,
        'endpoint'          => basename(__FILE__),
        'ed25519_backend'   => qq_ed25519_backend(),
        'php_version'       => PHP_VERSION,
        'secret_configured' => $secret !== '',
        'secret_len'        => strlen($secret),
    ];
    if ($secret !== '' && qq_ed25519_backend() !== 'none') {
        $info['derived_public_key'] = bin2hex(qq_ed25519_public_key($secret));
    }
    qq_wrap($info);
}

$payload = json_decode($rawBody, true);
if (!is_array($payload)) {
    qq_log('PARSE_ERROR', 'body is not valid json');
    qq_wrap(['code' => 0]); // 无法解析也返回 200，避免平台重推风暴
}

$op = $payload['op'] ?? null;

/* ======================================================================
 * 1) 【最高优先级】op=13 回调地址验证
 *    平台发送此请求时通常不带 X-Signature 头，因此必须在签名校验之前处理，
 *    否则会误判为“签名校验不通过”。
 *    处理方式：Bot Secret 重复至 32 字节作为 seed 派生 Ed25519 私钥，
 *             对 event_ts + plain_token 签名（Hex），返回 HTTP 200 + JSON。
 * ====================================================================== */
if ((int)$op === 13) {
    $d          = is_array($payload['d'] ?? null) ? $payload['d'] : [];
    $plainToken = (string)($d['plain_token'] ?? '');
    $eventTs    = (string)($d['event_ts'] ?? '');

    qq_log('OP13', [
        'plain_token' => $plainToken,
        'event_ts'    => $eventTs,
        'secret_len'  => strlen($secret),
    ]);

    if ($secret === '') {
        qq_wrap(['code' => 401, 'message' => 'app_secret 未配置，无法完成回调地址验证'], 401);
    }
    if ($plainToken === '' || $eventTs === '') {
        qq_wrap(['code' => 401, 'message' => 'invalid validation payload'], 401);
    }
    if (qq_ed25519_backend() === 'none') {
        qq_wrap(['code' => 500, 'message' => '需要 sodium 或 OpenSSL(1.1.1+) 扩展'], 500);
    }

    try {
        // 签名内容 = event_ts + plain_token，结果为 64 字节，需 Hex 编码
        $signature = bin2hex(qq_ed25519_sign($eventTs . $plainToken, $secret));
    } catch (Throwable $e) {
        qq_log('OP13_ERROR', $e->getMessage());
        qq_wrap(['code' => 500, 'message' => 'sign failed: ' . $e->getMessage()], 500);
    }

    qq_log('OP13_SIGNATURE', $signature);
    // 直接返回，HTTP 200
    qq_wrap(['plain_token' => $plainToken, 'signature' => $signature]);
}

/* ======================================================================
 * 2) 事件分发（op=0 等）：Ed25519 签名校验
 *    签名体 = timestamp + HTTP Body，用 Bot Secret 派生公钥验证。
 * ====================================================================== */
if ($secret !== '') {
    if (qq_ed25519_backend() === 'none') {
        qq_wrap(['code' => 500, 'message' => '需要 sodium 或 OpenSSL(1.1.1+) 扩展'], 500);
    }
    $sig = @hex2bin($sigHeader ?: '');
    if ($sigHeader === '' || $sig === false || strlen($sig) !== 64) {
        qq_log('SIG_FAIL', 'bad signature header');
        qq_wrap(['code' => 401, 'message' => 'invalid signature header'], 401);
    }
    if ($tsHeader === '') {
        qq_log('SIG_FAIL', 'missing timestamp');
        qq_wrap(['code' => 401, 'message' => 'missing timestamp'], 401);
    }
    try {
        // 签名体 = timestamp + HTTP Body
        if (!qq_ed25519_verify($sig, $tsHeader . $rawBody, $secret)) {
            qq_log('SIG_FAIL', 'verify failed');
            qq_wrap(['code' => 401, 'message' => 'signature verify failed'], 401);
        }
    } catch (Throwable $e) {
        qq_log('SIG_ERROR', $e->getMessage());
        qq_wrap(['code' => 500, 'message' => 'signature verify error: ' . $e->getMessage()], 500);
    }
}

$t  = (string)($payload['t'] ?? '');
$d  = is_array($payload['d'] ?? null) ? $payload['d'] : [];
$id = (string)($payload['id'] ?? '');

/* ========== 3) op=0 Dispatch 事件处理 ========== */
if ((int)$op === 0) {
    $appId = (string)($conf['app_id'] ?? '');

    // 3.1 用户添加机器人 -> 完成 QQ 强绑定
    if ($t === 'FRIEND_ADD') {
        $openid     = (string)($d['openid'] ?? '');
        $sceneParam = (string)($d['scene_param'] ?? ''); // 即 callback_data
        qq_log('FRIEND_ADD', ['openid' => $openid, 'scene_param' => $sceneParam]);
        if ($openid !== '') {
            $userId = null;
            if (preg_match('/uid:(\d+)/', $sceneParam, $m)) {
                $userId = (int)$m[1];
            }
            if ($userId) {
                try {
                    // 唯一键 (bot_app_id, qq_user_openid) 与 (user_id, bot_app_id)
                    $st = db()->prepare(
                        'INSERT INTO qq_bindings (user_id, bot_app_id, qq_user_openid, bound_at, count_reset_month)
                         VALUES (?, ?, ?, NOW(), ?)
                         ON DUPLICATE KEY UPDATE qq_user_openid = VALUES(qq_user_openid), bound_at = NOW()'
                    );
                    $st->execute([$userId, $appId, $openid, date('Y-m')]);
                    add_notification($userId, null, 'QQ 绑定成功，现在可以创建工单了。', 'inner');
                } catch (Throwable $e) {
                    qq_log('FRIEND_ADD_DB_ERROR', $e->getMessage()); // 忽略，仍返回 200
                }
                // 被动回复欢迎语（event_id 支持 FRIEND_ADD）
                @send_text($openid, "绑定成功！欢迎使用工单系统，可在网页端创建工单。", null, $id);
            }
        }
    }

    // 3.2 单聊消息：记录最近 msg_id 供 60 分钟内被动回复
    if ($t === 'C2C_MESSAGE_CREATE') {
        $openid = (string)($d['author']['user_openid'] ?? ($d['openid'] ?? ''));
        $msgId  = (string)($d['id'] ?? '');
        if ($openid !== '') {
            try {
                db()->prepare(
                    'UPDATE qq_bindings SET last_msg_id = ?, last_msg_at = NOW()
                     WHERE qq_user_openid = ? AND bot_app_id = ?'
                )->execute([$msgId, $openid, $appId]);
            } catch (Throwable $e) {
                qq_log('C2C_DB_ERROR', $e->getMessage()); // 忽略
            }
            if ($msgId !== '') {
                @send_text($openid, "收到您的消息～工单进度请登录工单系统查看，或在网页端创建新工单。", $msgId, null, 1);
            }
        }
    }
}

/* ========== 4) 兜底：始终返回 HTTP 200 与 {"code":0} ========== */
qq_wrap(['code' => 0]);
