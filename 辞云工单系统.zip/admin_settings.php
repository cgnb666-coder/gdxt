<?php
// admin_settings.php — 系统设置：QQ 机器人、邮件服务（SMTP）、站点信息、通知策略参数
declare(strict_types=1);
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/qq_send.php';
require_once __DIR__ . '/mailer.php';
require_once __DIR__ . '/ai.php';

$u = require_agent();

$fields = [
    'qq_app_id'                   => 'QQ 机器人 AppID',
    'qq_app_secret'               => 'Bot Secret（AppSecret）',
    'qq_client_secret'            => 'ClientSecret（留空则同 Bot Secret）',
    'app_name'                    => '站点名称',
    'app_company'                 => '公司名称',
    'app_base_url'                => '站点根地址（含协议，结尾不带 /）',
    'proactive_monthly_limit'     => '单聊主动消息每月上限',
    'processing_inner_threshold'  => 'processing 走站内的阈值',
    'mail_enabled'                => '启用邮件服务',
    'mail_host'                   => 'SMTP 服务器',
    'mail_port'                   => 'SMTP 端口',
    'mail_secure'                 => '加密方式（ssl / tls / none）',
    'mail_user'                   => 'SMTP 账号',
    'mail_pass'                   => 'SMTP 密码 / 授权码',
    'mail_from'                   => '发件邮箱',
    'mail_from_name'              => '发件人名称',
    'notify_admin_email'          => '管理员通知邮箱',
    'ai_enabled'                  => '启用 AI',
    'ai_base_url'                 => 'AI 接口地址',
    'ai_api_key'                  => 'AI API Key',
    'ai_model'                    => 'AI 模型',
    'ai_temperature'              => 'AI 温度（0~2）',
    'ai_max_tokens'               => 'AI 最大输出长度',
    'ai_auto_reply'               => 'AI 自动回复',
    'ai_signature'                => 'AI 回复署名',
    'ai_system_prompt'            => 'AI 系统提示词',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();

    // 测试发信
    if (($_POST['action'] ?? '') === 'test_mail') {
        $to  = trim((string)($_POST['test_to'] ?? ''));
        $err = null;
        if (!filter_var($to, FILTER_VALIDATE_EMAIL)) {
            flash_set('danger', '请填写有效的测试收件邮箱。');
        } elseif (!mail_configured()) {
            flash_set('danger', '邮件服务未启用或未配置完整，请先保存配置。');
        } elseif (smtp_send($to, '【' . mail_conf()['from_name'] . '】测试邮件', '<p>这是一封测试邮件，收到即表示邮件服务配置成功。</p>', $err)) {
            flash_set('success', '测试邮件已发送至 ' . $to . '，请查收。');
        } else {
            flash_set('danger', '发送失败：' . $err);
        }
        header('Location: admin_settings.php');
        exit;
    }

    // 测试 AI 连通性
    if (($_POST['action'] ?? '') === 'test_ai') {
        $err = null;
        $txt = ai_chat([
            ['role' => 'system', 'content' => (trim((string)setting_get('ai_system_prompt', '')) !== '' ? (string)setting_get('ai_system_prompt', '') : ai_default_prompt())],
            ['role' => 'user',   'content' => '这是一条连通性测试，请用一句话回复「连接正常」。'],
        ], $err);
        if ($txt === '') {
            flash_set('danger', 'AI 测试失败：' . $err);
        } else {
            flash_set('success', 'AI 测试成功。模型回复：' . $txt);
        }
        header('Location: admin_settings.php');
        exit;
    }

    $checkboxes = ['mail_enabled', 'ai_enabled', 'ai_auto_reply'];
    foreach ($fields as $key => $label) {
        if (in_array($key, $checkboxes, true)) {
            setting_set($key, isset($_POST[$key]) ? '1' : '0');
            continue;
        }
        if (array_key_exists($key, $_POST)) {
            setting_set($key, trim((string)$_POST[$key]));
        }
    }
    // 配置变更后失效 token 缓存
    @unlink(QQ_TOKEN_FILE);
    flash_set('success', '设置已保存。');
    header('Location: admin_settings.php');
    exit;
}

function cur(string $key): string
{
    $defaults = [
        'app_name'                   => config()['app']['name'] ?? '工单系统',
        'app_company'                => config()['app']['company'] ?? '示例科技有限公司',
        'app_base_url'               => config()['app']['base_url'] ?? '',
        'proactive_monthly_limit'    => (string)(config()['app']['proactive_monthly_limit'] ?? 4),
        'processing_inner_threshold' => (string)(config()['app']['processing_inner_threshold'] ?? 2),
        'qq_app_id'                  => config()['qq']['app_id'] ?? '',
        'qq_app_secret'              => config()['qq']['app_secret'] ?? '',
        'qq_client_secret'           => config()['qq']['client_secret'] ?? '',
        'mail_enabled'               => '0',
        'mail_host'                  => '',
        'mail_port'                  => '465',
        'mail_secure'                => 'ssl',
        'mail_user'                  => '',
        'mail_pass'                  => '',
        'mail_from'                  => '',
        'mail_from_name'             => config()['app']['company'] ?? '工单系统',
        'notify_admin_email'         => $GLOBALS['u']['email'] ?? '',
        'ai_enabled'                 => '0',
        'ai_base_url'                => config()['ai']['base_url'] ?? '',
        'ai_api_key'                 => config()['ai']['api_key'] ?? '',
        'ai_model'                   => config()['ai']['model'] ?? '',
        'ai_temperature'             => '0.3',
        'ai_max_tokens'              => '800',
        'ai_auto_reply'              => '0',
        'ai_signature'               => config()['app']['company'] ?? 'AI 客服助手',
        'ai_system_prompt'           => ai_default_prompt(),
    ];
    return (string)setting_get($key, $defaults[$key] ?? '');
}

$webhookUrl = base_url() . '/qq_webhook.php';

$IS_AGENT_LAYOUT = true;
$ACTIVE_MENU     = 'settings';
$PAGE_TITLE      = '系统设置';
$BREADCRUMB      = ['系统', '系统设置'];
include __DIR__ . '/header.php';
?>
<div class="split">
  <div class="split-left">
    <div class="card">
      <h3 class="card-title"><span class="dot"></span>QQ 机器人配置</h3>
      <form method="post">
        <?= csrf_field() ?>
        <div class="form-group">
          <label for="qq_app_id">QQ 机器人 AppID</label>
          <input id="qq_app_id" name="qq_app_id" type="text" value="<?= e(cur('qq_app_id')) ?>" class="mono" placeholder="如 102xxxxxx">
        </div>
        <div class="form-group">
          <label for="qq_app_secret">Bot Secret（AppSecret）</label>
          <input id="qq_app_secret" name="qq_app_secret" type="text" value="<?= e(cur('qq_app_secret')) ?>" class="mono" placeholder="用于 Ed25519 签名校验">
          <div class="form-hint">同时用于获取 access_token 与回调签名校验，请妥善保管。</div>
        </div>
        <div class="form-group">
          <label for="qq_client_secret">ClientSecret</label>
          <input id="qq_client_secret" name="qq_client_secret" type="text" value="<?= e(cur('qq_client_secret')) ?>" class="mono" placeholder="留空则与 Bot Secret 相同">
        </div>

        <h3 class="card-title mt16"><span class="dot"></span>邮件服务（发送邮箱验证码）</h3>
        <div class="form-group">
          <label style="display:flex;align-items:center;gap:8px;cursor:pointer">
            <input type="checkbox" name="mail_enabled" value="1" <?= cur('mail_enabled') === '1' ? 'checked' : '' ?> style="width:auto">
            启用邮件服务
          </label>
          <div class="form-hint">未启用时，客户注册页会直接显示验证码以便调试；启用后将仅通过邮件送达。</div>
        </div>
        <div class="form-group">
          <label for="mailPreset">常见邮箱服务商（选择后自动填入下方服务器/端口/加密）</label>
          <select id="mailPreset">
            <option value="">— 自定义 / 保持当前 —</option>
            <option value="qq|smtp.qq.com|465|ssl">QQ 邮箱（smtp.qq.com:465 SSL）</option>
            <option value="163|smtp.163.com|465|ssl">网易 163 邮箱（smtp.163.com:465 SSL）</option>
            <option value="126|smtp.126.com|465|ssl">网易 126 邮箱（smtp.126.com:465 SSL）</option>
            <option value="qiye163|smtp.qiye.163.com|465|ssl">网易企业邮箱（smtp.qiye.163.com:465 SSL）</option>
            <option value="exmail|smtp.exmail.qq.com|465|ssl">腾讯企业邮箱（smtp.exmail.qq.com:465 SSL）</option>
            <option value="aliyun|smtp.mxhichina.com|465|ssl">阿里云企业邮箱（smtp.mxhichina.com:465 SSL）</option>
            <option value="gmail|smtp.gmail.com|465|ssl">Gmail（smtp.gmail.com:465 SSL，需应用专用密码）</option>
            <option value="outlook|smtp.office365.com|587|tls">Outlook / Office365（smtp.office365.com:587 STARTTLS）</option>
            <option value="sendgrid|smtp.sendgrid.net|587|tls">SendGrid（smtp.sendgrid.net:587 STARTTLS）</option>
          </select>
          <div class="form-hint">提示：多数国内邮箱需在邮箱设置中开启 SMTP 并使用「授权码」而非登录密码。</div>
        </div>
        <div class="form-grid">
          <div class="form-group">
            <label for="mail_host">SMTP 服务器</label>
            <input id="mail_host" name="mail_host" type="text" value="<?= e(cur('mail_host')) ?>" class="mono" placeholder="smtp.example.com">
          </div>
          <div class="form-group">
            <label for="mail_port">端口</label>
            <input id="mail_port" name="mail_port" type="number" min="1" max="65535" value="<?= e(cur('mail_port')) ?>" class="mono">
          </div>
          <div class="form-group">
            <label for="mail_secure">加密方式</label>
            <select id="mail_secure" name="mail_secure">
              <?php foreach (['ssl' => 'SSL（465）', 'tls' => 'STARTTLS（587）', 'none' => '不加密'] as $k => $v): ?>
                <option value="<?= e($k) ?>" <?= cur('mail_secure') === $k ? 'selected' : '' ?>><?= e($v) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="form-group">
            <label for="mail_from_name">发件人名称</label>
            <input id="mail_from_name" name="mail_from_name" type="text" value="<?= e(cur('mail_from_name')) ?>">
          </div>
          <div class="form-group">
            <label for="mail_user">SMTP 账号</label>
            <input id="mail_user" name="mail_user" type="text" value="<?= e(cur('mail_user')) ?>" class="mono" placeholder="完整邮箱地址">
          </div>
          <div class="form-group">
            <label for="mail_pass">SMTP 密码 / 授权码</label>
            <input id="mail_pass" name="mail_pass" type="text" value="<?= e(cur('mail_pass')) ?>" class="mono" placeholder="邮箱授权码">
          </div>
        </div>
        <div class="form-group">
          <label for="mail_from">发件邮箱</label>
          <input id="mail_from" name="mail_from" type="text" value="<?= e(cur('mail_from')) ?>" class="mono" placeholder="一般与 SMTP 账号相同">
          <div class="form-hint">务必与 SMTP 账号一致，否则邮件易被判为垃圾邮件或发送失败。</div>
        </div>
        <div class="form-group">
          <label for="notify_admin_email">管理员通知邮箱（超级管理员 / 客服收工单提醒）</label>
          <input id="notify_admin_email" name="notify_admin_email" type="text" value="<?= e(cur('notify_admin_email')) ?>" class="mono" placeholder="admin@example.com，多个用逗号分隔">
          <div class="form-hint">收到「新工单提交」「客户追加回复」等工单提醒；留空则不发送管理员通知。</div>
        </div>

        <h3 class="card-title mt16"><span class="dot"></span>站点信息</h3>
        <div class="form-grid">
          <div class="form-group">
            <label for="app_name">站点名称</label>
            <input id="app_name" name="app_name" type="text" value="<?= e(cur('app_name')) ?>">
          </div>
          <div class="form-group">
            <label for="app_company">公司名称</label>
            <input id="app_company" name="app_company" type="text" value="<?= e(cur('app_company')) ?>">
          </div>
        </div>
        <div class="form-group">
          <label for="app_base_url">站点根地址</label>
          <input id="app_base_url" name="app_base_url" type="text" value="<?= e(cur('app_base_url')) ?>" class="mono" placeholder="https://ticket.example.com">
          <div class="form-hint">用于生成 QQ 回调地址与跳转链接，留空则自动推断。</div>
        </div>

        <h3 class="card-title mt16"><span class="dot"></span>通知策略</h3>
        <div class="form-grid">
          <div class="form-group">
            <label for="proactive_monthly_limit">单聊主动消息每月上限</label>
            <input id="proactive_monthly_limit" name="proactive_monthly_limit" type="number" min="0" max="1000" value="<?= e(cur('proactive_monthly_limit')) ?>">
            <div class="form-hint">官方频控更宽松，此处按产品策略自行收紧（默认 4 条/月/用户）。</div>
          </div>
          <div class="form-group">
            <label for="processing_inner_threshold">processing 走站内阈值</label>
            <input id="processing_inner_threshold" name="processing_inner_threshold" type="number" min="0" max="100" value="<?= e(cur('processing_inner_threshold')) ?>">
            <div class="form-hint">当月主动已用低于该值才额外推送。</div>
          </div>
        </div>

        <h3 class="card-title mt16"><span class="dot"></span>AI 客服设置</h3>
        <div class="form-group">
          <label style="display:flex;align-items:center;gap:8px;cursor:pointer">
            <input type="checkbox" name="ai_enabled" value="1" <?= cur('ai_enabled') === '1' ? 'checked' : '' ?> style="width:auto">
            启用 AI 能力
          </label>
          <div class="form-hint">启用后，客服可在工单详情点击「AI 生成回复」；也可开启自动回复。</div>
        </div>
        <div class="form-group">
          <label for="aiPreset">常见 AI 服务商（选择后自动填入接口地址与模型）</label>
          <select id="aiPreset">
            <option value="">— 自定义 / 保持当前 —</option>
            <option value="https://api.deepseek.com/v1|deepseek-chat">DeepSeek（deepseek-chat）</option>
            <option value="https://dashscope.aliyuncs.com/compatible-mode/v1|qwen-plus">通义千问（qwen-plus）</option>
            <option value="https://open.bigmodel.cn/api/paas/v4|glm-4-flash">智谱 GLM（glm-4-flash）</option>
            <option value="https://api.moonshot.cn/v1|moonshot-v1-8k">月之暗面 Kimi（moonshot-v1-8k）</option>
            <option value="https://api.openai.com/v1|gpt-4o-mini">OpenAI（gpt-4o-mini）</option>
          </select>
          <div class="form-hint">以上均兼容 OpenAI 的 /chat/completions 协议，填写各自的 API Key 即可。</div>
        </div>
        <div class="form-group">
          <label for="ai_base_url">AI 接口地址（Base URL）</label>
          <input id="ai_base_url" name="ai_base_url" type="text" value="<?= e(cur('ai_base_url')) ?>" class="mono" placeholder="https://api.deepseek.com/v1">
          <div class="form-hint">系统会自动在其后拼接 /chat/completions。</div>
        </div>
        <div class="form-grid">
          <div class="form-group">
            <label for="ai_api_key">API Key</label>
            <input id="ai_api_key" name="ai_api_key" type="text" value="<?= e(cur('ai_api_key')) ?>" class="mono" placeholder="sk-...">
          </div>
          <div class="form-group">
            <label for="ai_model">模型</label>
            <input id="ai_model" name="ai_model" type="text" value="<?= e(cur('ai_model')) ?>" class="mono" placeholder="deepseek-chat">
          </div>
          <div class="form-group">
            <label for="ai_temperature">温度（0~2）</label>
            <input id="ai_temperature" name="ai_temperature" type="number" step="0.1" min="0" max="2" value="<?= e(cur('ai_temperature')) ?>">
          </div>
          <div class="form-group">
            <label for="ai_max_tokens">最大输出长度</label>
            <input id="ai_max_tokens" name="ai_max_tokens" type="number" min="64" max="8192" value="<?= e(cur('ai_max_tokens')) ?>">
          </div>
        </div>
        <div class="form-group">
          <label style="display:flex;align-items:center;gap:8px;cursor:pointer">
            <input type="checkbox" name="ai_auto_reply" value="1" <?= cur('ai_auto_reply') === '1' ? 'checked' : '' ?> style="width:auto">
            客户提交工单后由 AI 自动回复
          </label>
          <div class="form-hint">开启后，新工单会立即收到一条 AI 回复（同时按邮件规则通知客户）。建议先在详情页人工确认效果后再开启。</div>
        </div>
        <div class="form-group">
          <label for="ai_signature">AI 回复署名（可留空）</label>
          <input id="ai_signature" name="ai_signature" type="text" value="<?= e(cur('ai_signature')) ?>">
          <div class="form-hint">自动回复时追加在正文末尾，例如「AI 客服助手」。</div>
        </div>
        <div class="form-group">
          <label for="ai_system_prompt">AI 系统提示词（训导）</label>
          <textarea id="ai_system_prompt" name="ai_system_prompt" rows="14" class="mono" style="font-size:12.5px"><?= e(cur('ai_system_prompt')) ?></textarea>
          <div class="form-hint">决定 AI 的角色与回复风格。默认已内置一套客服提示词，可在此基础上按你的业务微调。</div>
        </div>

        <button class="btn btn-primary" type="submit">保存设置</button>
      </form>
    </div>
  </div>

  <aside class="split-right">
    <div class="card">
      <h3 class="card-title"><span class="dot"></span>测试发信</h3>
      <p class="muted mb8">保存上方配置后，向指定邮箱发送一封测试邮件。</p>
      <form method="post" class="flex gap8">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="test_mail">
        <input type="email" name="test_to" required placeholder="收件邮箱" style="flex:1" value="<?= e($u['email']) ?>">
        <button class="btn btn-ghost" type="submit">发送</button>
      </form>
      <div class="form-hint mt8">若失败，请核对：服务器/端口/加密方式是否匹配、是否使用授权码、发件邮箱是否与账号一致。</div>
    </div>

    <div class="card">
      <h3 class="card-title"><span class="dot"></span>测试 AI</h3>
      <p class="muted mb8">保存上方 AI 配置后，点此验证接口连通性。</p>
      <form method="post">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="test_ai">
        <button class="btn btn-ghost btn-block" type="submit">发送测试请求</button>
      </form>
      <div class="form-hint mt8">测试结果会以提示条形式显示在页面顶部。</div>
    </div>

    <div class="card">
      <h3 class="card-title"><span class="dot"></span>回调地址</h3>
      <p class="muted mb8">在 QQ 开放平台「开发设置 - 回调地址」中填写：</p>
      <div class="mono" style="word-break:break-all;background:rgba(0,0,0,.25);padding:10px;border-radius:8px"><?= e($webhookUrl) ?></div>
      <button class="btn btn-ghost btn-block mt12" type="button" data-copy="<?= e($webhookUrl) ?>">复制回调地址</button>
      <div class="form-hint">平台会以 op=13 请求该地址进行验证，本系统已实现 Ed25519 签名应答。</div>
    </div>

    <div class="card">
      <h3 class="card-title"><span class="dot"></span>接入要点</h3>
      <ol class="muted" style="padding-left:18px;line-height:1.9;font-size:12.5px">
        <li>access_token：<span class="mono">POST api.bot.qq.com/app/getAppAccessToken</span>，有效期 7200s，过期前 60s 自动刷新。</li>
        <li>鉴权头：<span class="mono">Authorization: QQBot ACCESS_TOKEN</span>。</li>
        <li>单聊消息：<span class="mono">POST /v2/users/{openid}/messages</span>，msg_type=0。</li>
        <li>被动回复：msg_id（60 分钟内）或 event_id，二选一；msg_id 需带 msg_seq 防重。</li>
        <li>回调监听需订阅 C2C_MESSAGE_CREATE、FRIEND_ADD、C2C_MSG_RECEIVE 等事件。</li>
      </ol>
    </div>
  </aside>
</div>

<script>
// 服务商预设：选择后自动填入对应字段
(function () {
  var mail = document.getElementById('mailPreset');
  if (mail) {
    mail.addEventListener('change', function () {
      if (!this.value) return;
      var p = this.value.split('|');
      document.getElementById('mail_host').value = p[1] || '';
      document.getElementById('mail_port').value = p[2] || '';
      document.getElementById('mail_secure').value = p[3] || 'ssl';
    });
  }
  var ai = document.getElementById('aiPreset');
  if (ai) {
    ai.addEventListener('change', function () {
      if (!this.value) return;
      var p = this.value.split('|');
      document.getElementById('ai_base_url').value = p[0] || '';
      document.getElementById('ai_model').value = p[1] || '';
    });
  }
})();
</script>
<?php include __DIR__ . '/footer.php'; ?>
