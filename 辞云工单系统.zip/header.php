<?php
// header.php — 全站公共头部：<head>、背景装饰、品牌头 / 后台侧边栏 + 顶部栏
// 使用前可设置：$PAGE_TITLE、$IS_AGENT_LAYOUT、$ACTIVE_MENU、$BREADCRUMB、$PAGE_LEAD
declare(strict_types=1);

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';

$__u  = current_user();
$__cfg = config();

$PAGE_TITLE      = $PAGE_TITLE ?? ($__cfg['app']['name'] ?? '工单系统');
$PAGE_LEAD       = $PAGE_LEAD ?? '';
$IS_AGENT_LAYOUT = $IS_AGENT_LAYOUT ?? false;
$ACTIVE_MENU     = $ACTIVE_MENU ?? '';
$BREADCRUMB      = $BREADCRUMB ?? [];
$__company       = $__cfg['app']['company'] ?? '示例科技有限公司';
$__flash         = flash_take();

if ($IS_AGENT_LAYOUT) {
    require_once __DIR__ . '/qq_send.php'; // 供顶部栏未读通知使用
}

// 侧边栏菜单定义（含内联 SVG 图标）
$__navGroups = [
    [
        'title' => '概览',
        'items' => [
            ['key' => 'dashboard', 'label' => '仪表盘', 'href' => 'agent_dashboard.php',
             'icon' => '<path d="M3 13h8V3H3v10zm10 8h8V3h-8v18zM3 21h8v-6H3v6z"/>'],
        ],
    ],
    [
        'title' => '工单管理',
        'items' => [
            ['key' => 'tickets',            'label' => '全部工单', 'href' => 'agent_tickets.php',
             'icon' => '<path d="M4 5h16v4a2 2 0 0 0 0 4v4H4v-4a2 2 0 0 0 0-4V5zm10 0v4a2 2 0 0 0 0 4v4"/>'],
            ['key' => 'tickets_open',       'label' => '待处理', 'href' => 'agent_tickets.php?status=open',
             'icon' => '<path d="M12 8v5l3 2M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18z"/>'],
            ['key' => 'tickets_processing', 'label' => '处理中', 'href' => 'agent_tickets.php?status=processing',
             'icon' => '<path d="M12 3v3m0 12v3m9-9h-3M6 12H3m14.5-6.5-2 2m-7 7-2 2m11 0-2-2m-7-7-2-2"/>'],
            ['key' => 'tickets_replied',    'label' => '已回复', 'href' => 'agent_tickets.php?status=replied',
             'icon' => '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>'],
            ['key' => 'tickets_closed',     'label' => '已关闭', 'href' => 'agent_tickets.php?status=closed',
             'icon' => '<path d="M20 6 9 17l-5-5"/>'],
        ],
    ],
    [
        'title' => '组织管理',
        'items' => [
            ['key' => 'users',  'label' => '用户管理', 'href' => 'admin_users.php?role=customer',
             'icon' => '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8zm13 10v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>'],
            ['key' => 'agents', 'label' => '客服管理', 'href' => 'admin_users.php?role=agent',
             'icon' => '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2M12 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8z"/>'],
        ],
    ],
    [
        'title' => '系统',
        'items' => [
            ['key' => 'settings', 'label' => '系统设置', 'href' => 'admin_settings.php',
             'icon' => '<path d="M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>'],
        ],
    ],
];

$__unread = 0;
if ($__u) {
    try {
        $st = db()->prepare('SELECT COUNT(*) c FROM notifications WHERE user_id = ? AND is_read = 0');
        $st->execute([(int)$__u['id']]);
        $__unread = (int)($st->fetch()['c'] ?? 0);
    } catch (Throwable $e) {
        $__unread = 0;
    }
}

/**
 * 内联品牌 Logo（科技感 SVG）。
 */
$__logo = '<svg viewBox="0 0 48 48" width="100%" height="100%" fill="none" xmlns="http://www.w3.org/2000/svg">'
    . '<defs><linearGradient id="lg" x1="0" y1="0" x2="48" y2="48" gradientUnits="userSpaceOnUse">'
    . '<stop stop-color="#00e5ff"/><stop offset="1" stop-color="#7c4dff"/></linearGradient></defs>'
    . '<path d="M24 4 40 12v14c0 9-7 16-16 18C15 42 8 35 8 26V12L24 4z" stroke="url(#lg)" stroke-width="2" fill="rgba(0,229,255,0.06)"/>'
    . '<path d="M17 24h5l3-7 3 14 3-7h4" stroke="url(#lg)" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/>'
    . '</svg>';
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="color-scheme" content="dark">
<title><?= e($PAGE_TITLE) ?> · <?= e($__company) ?></title>
<link rel="stylesheet" href="assets/style.css">
</head>
<body class="<?= $IS_AGENT_LAYOUT ? 'layout-agent' : 'layout-customer' ?>">
<div class="bg-decor" aria-hidden="true"></div>

<?php if ($IS_AGENT_LAYOUT): ?>
<!-- ============ 后台：侧边栏 + 顶部栏 + 内容区 ============ -->
<div class="app-shell">
  <aside class="sidebar" id="sidebar">
    <div class="sidebar-brand">
      <span class="logo"><?= $__logo ?></span>
      <span class="brand-text">
        <strong>工单系统</strong>
        <small>TICKET SYSTEM</small>
      </span>
    </div>
    <div class="sidebar-company"><?= e($__company) ?></div>
    <nav class="sidebar-nav">
      <?php foreach ($__navGroups as $__g): ?>
        <div class="nav-group">
          <div class="nav-group-title"><?= e($__g['title']) ?></div>
          <?php foreach ($__g['items'] as $__it): ?>
            <a class="nav-item <?= $ACTIVE_MENU === $__it['key'] ? 'active' : '' ?>" href="<?= e($__it['href']) ?>">
              <span class="nav-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"
                stroke-linecap="round" stroke-linejoin="round"><?= $__it['icon'] ?></svg></span>
              <span class="nav-label"><?= e($__it['label']) ?></span>
            </a>
          <?php endforeach; ?>
        </div>
      <?php endforeach; ?>
    </nav>
    <div class="sidebar-foot">
      <span class="avatar" style="background:<?= e($__u['avatar_color'] ?? '#00e5ff') ?>"><?= e(initial($__u['username'] ?? '?')) ?></span>
      <span class="foot-user">
        <strong><?= e($__u['username'] ?? '') ?></strong>
        <small><?= ($__u['role'] ?? '') === 'agent' ? '客服' : '用户' ?></small>
      </span>
      <a class="foot-logout" href="logout.php" title="退出登录">退出</a>
    </div>
  </aside>
  <div class="sidebar-overlay" id="sidebarOverlay"></div>

  <div class="main">
    <header class="topbar">
      <div class="topbar-left">
        <button class="icon-btn hamburger" id="hamburger" type="button" aria-label="菜单">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M3 6h18M3 12h18M3 18h18"/></svg>
        </button>
        <nav class="breadcrumb">
          <?php $__bc = $BREADCRUMB ?: [$PAGE_TITLE]; $__i = 0; $__n = count($__bc); foreach ($__bc as $__b): $__i++; ?>
            <?php if ($__i < $__n): ?><span><?= e($__b) ?></span><i>/</i><?php else: ?><b><?= e($__b) ?></b><?php endif; ?>
          <?php endforeach; ?>
        </nav>
      </div>
      <form class="search-box" action="agent_tickets.php" method="get" role="search">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>
        <input type="search" name="q" placeholder="搜索工单编号 / 标题 / 客户…" value="<?= e($_GET['q'] ?? '') ?>">
      </form>
      <div class="topbar-right">
        <a class="icon-btn bell" href="agent_dashboard.php" aria-label="通知">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8a6 6 0 1 0-12 0c0 7-3 9-3 9h18s-3-2-3-9M13.7 21a2 2 0 0 1-3.4 0"/></svg>
          <?php if ($__unread > 0): ?><b class="badge-dot"><?= $__unread > 99 ? '99+' : (int)$__unread ?></b><?php endif; ?>
        </a>
        <div class="admin-dropdown">
          <button class="admin-btn" type="button" id="adminBtn">
            <span class="avatar sm" style="background:<?= e($__u['avatar_color'] ?? '#00e5ff') ?>"><?= e(initial($__u['username'] ?? '?')) ?></span>
            <span class="admin-name"><?= e($__u['username'] ?? '') ?></span>
            <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><path d="m6 9 6 6 6-6"/></svg>
          </button>
          <div class="admin-menu" id="adminMenu">
            <a href="admin_settings.php">系统设置</a>
            <a href="logout.php">退出登录</a>
          </div>
        </div>
      </div>
    </header>
    <div class="content">
      <?php if ($PAGE_LEAD !== ''): ?><div class="page-head"><h1><?= e($PAGE_TITLE) ?></h1><p class="muted"><?= e($PAGE_LEAD) ?></p></div><?php endif; ?>
      <?php if ($__flash): ?><div class="alert alert-<?= e($__flash['type']) ?>"><?= e($__flash['msg']) ?></div><?php endif; ?>

<?php else: ?>
<!-- ============ 客户侧：品牌头 + 内容区 ============ -->
<header class="site-header">
  <a class="brand" href="index.php">
    <span class="logo"><?= $__logo ?></span>
    <span class="brand-text">
      <strong>工单系统</strong>
      <small>TICKET SYSTEM</small>
    </span>
  </a>
  <div class="brand-company"><?= e($__company) ?></div>
  <div class="site-user">
    <?php if ($__u): ?>
      <span class="avatar sm" style="background:<?= e($__u['avatar_color'] ?? '#00e5ff') ?>"><?= e(initial($__u['username'])) ?></span>
      <span class="user-meta"><strong><?= e($__u['username']) ?></strong><small><?= $__u['role'] === 'agent' ? '客服' : '客户' ?></small></span>
      <?php if ($__u['role'] !== 'agent'): ?>
        <a class="btn btn-ghost btn-sm" href="bind_guide.php">QQ 通知</a>
      <?php endif; ?>
      <a class="btn btn-ghost btn-sm" href="logout.php">登出</a>
    <?php else: ?>
      <a class="btn btn-ghost btn-sm" href="login.php">登录</a>
      <a class="btn btn-primary btn-sm" href="register.php">注册</a>
    <?php endif; ?>
  </div>
</header>
<main class="container">
  <?php if ($PAGE_LEAD !== ''): ?><div class="page-head"><h1><?= e($PAGE_TITLE) ?></h1><p class="muted"><?= e($PAGE_LEAD) ?></p></div>
  <?php elseif ($PAGE_TITLE && !in_array(basename($_SERVER['SCRIPT_NAME'] ?? ''), ['index.php','ticket_list.php','login.php','register.php','bind_guide.php','verify_email.php'], true)): ?>
    <div class="page-head"><h1><?= e($PAGE_TITLE) ?></h1></div>
  <?php endif; ?>
  <?php if ($__flash): ?><div class="alert alert-<?= e($__flash['type']) ?>"><?= e($__flash['msg']) ?></div><?php endif; ?>
<?php endif; ?>
