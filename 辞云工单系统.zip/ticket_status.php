<?php
// ticket_status.php — 客服工单状态流转（接单/标记已回复/关闭），并通知客户（QQ + 邮件）
declare(strict_types=1);
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/qq_send.php';
require_once __DIR__ . '/mailer.php';

$u = require_agent();

$ticketId = (int)($_POST['ticket_id'] ?? $_GET['ticket_id'] ?? 0);
$action   = (string)($_POST['action'] ?? $_GET['action'] ?? '');
$back     = (string)($_POST['back'] ?? 'agent_ticket_detail.php?id=' . $ticketId);

$map = [
    'accept' => ['status' => 'processing', 'note' => '客服已接单，正在处理。'],
    'reply'  => ['status' => 'replied',    'note' => '客服已回复。'],
    'close'  => ['status' => 'closed',     'note' => '工单已关闭。'],
];

if (!isset($map[$action])) {
    flash_set('danger', '未知操作。');
    header('Location: ' . $back);
    exit;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
}

$st = db()->prepare('SELECT * FROM tickets WHERE id = ? LIMIT 1');
$st->execute([$ticketId]);
$t = $st->fetch();
if (!$t) {
    flash_set('danger', '工单不存在。');
    header('Location: agent_tickets.php');
    exit;
}

$newStatus = $map[$action]['status'];

// 接单时认领；其余操作保留原客服
$assign = $t['assigned_agent_id'] ?: (int)$u['id'];
if ($action === 'accept') {
    $assign = (int)$u['id'];
}

db()->prepare('UPDATE tickets SET status = ?, assigned_agent_id = ?, updated_at = NOW() WHERE id = ?')
    ->execute([$newStatus, $assign, $ticketId]);

// 输出到时间线
db()->prepare('INSERT INTO ticket_replies (ticket_id, user_id, content, reply_type, created_at)
               VALUES (?, ?, ?, "system", NOW())')
    ->execute([$ticketId, (int)$u['id'], $map[$action]['note']]);

// 通知客户（QQ 策略 + 邮件，成功 / 站内降级由策略决定）
qq_notify_ticket($ticketId, $newStatus, (string)$u['username']);
email_notify_ticket($ticketId, $newStatus, (string)$u['username']);

flash_set('success', $map[$action]['note'] . ' 状态已更新为「' . status_label($newStatus) . '」。');
header('Location: ' . $back);
exit;
