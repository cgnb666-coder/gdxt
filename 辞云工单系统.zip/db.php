<?php
// db.php — 配置读取 / PDO 单例连接 / 通用助手函数（所有页面 include）
declare(strict_types=1);

/**
 * 读取 config.php 配置（单例缓存）。未安装时跳转安装向导。
 */
function config(): array
{
    static $cfg = null;
    if ($cfg === null) {
        $file = __DIR__ . '/config.php';
        if (!is_file($file)) {
            // 未完成安装
            if (basename($_SERVER['SCRIPT_NAME'] ?? '') !== 'install.php') {
                header('Location: install.php');
                exit;
            }
            return [];
        }
        $cfg = require $file;
    }
    return is_array($cfg) ? $cfg : [];
}

/**
 * PDO 单例（utf8mb4，异常模式，真实预处理）。
 */
function db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        $c   = config()['db'] ?? [];
        $dsn = sprintf(
            'mysql:host=%s;port=%d;dbname=%s;charset=%s',
            $c['host'] ?? '127.0.0.1',
            (int)($c['port'] ?? 3306),
            $c['name'] ?? '',
            $c['charset'] ?? 'utf8mb4'
        );
        $pdo = new PDO($dsn, $c['user'] ?? '', $c['pass'] ?? '', [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]);
    }
    return $pdo;
}

/**
 * 轻量幂等迁移：为老库补齐字段（新版首次访问自动升级，无需重装）。
 * v2：users 邮箱验证字段；v3：ticket_replies.reply_type 增加 'ai'。
 */
function db_ensure_schema(): void
{
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;
    try {
        $ver = (int)setting_get('schema_version', '1');
        if ($ver >= 3) {
            return;
        }
        if ($ver < 2) {
            $cols = db()->query('SHOW COLUMNS FROM users')->fetchAll(PDO::FETCH_COLUMN);
            $add  = [];
            if (!in_array('email_verified_at', $cols, true)) {
                $add[] = 'ADD COLUMN email_verified_at DATETIME NULL DEFAULT NULL';
            }
            if (!in_array('verify_code', $cols, true)) {
                $add[] = 'ADD COLUMN verify_code VARCHAR(12) NULL DEFAULT NULL';
            }
            if (!in_array('verify_expires', $cols, true)) {
                $add[] = 'ADD COLUMN verify_expires DATETIME NULL DEFAULT NULL';
            }
            if ($add) {
                db()->exec('ALTER TABLE users ' . implode(', ', $add));
            }
        }
        if ($ver < 3) {
            db()->exec("ALTER TABLE ticket_replies MODIFY COLUMN reply_type ENUM('customer','agent','system','ai') NOT NULL DEFAULT 'customer'");
        }
        setting_set('schema_version', '3');
    } catch (Throwable $e) {
        // 迁移失败不阻断业务
    }
}

/**
 * HTML 转义输出。
 */
function e($s): string
{
    return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/**
 * 读取系统设置（settings 表），带默认值。
 */
function setting_get(string $key, $default = null)
{
    static $cache = [];
    if (array_key_exists($key, $cache)) {
        return $cache[$key];
    }
    try {
        $st = db()->prepare('SELECT v FROM settings WHERE k = ? LIMIT 1');
        $st->execute([$key]);
        $row = $st->fetch();
        $val = $row ? $row['v'] : null;
    } catch (Throwable $e) {
        $val = null;
    }
    if ($val === null || $val === '') {
        $val = $default;
    }
    return $cache[$key] = $val;
}

/**
 * 写入系统设置。
 */
function setting_set(string $key, string $value): void
{
    $st = db()->prepare(
        'INSERT INTO settings (k, v) VALUES (?, ?) ON DUPLICATE KEY UPDATE v = VALUES(v)'
    );
    $st->execute([$key, $value]);
}

/**
 * 生成 UUID v4。
 */
function uuid4(): string
{
    $d = random_bytes(16);
    $d[6] = chr((ord($d[6]) & 0x0f) | 0x40);
    $d[8] = chr((ord($d[8]) & 0x3f) | 0x80);
    return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($d), 4));
}

/**
 * 头像首字母。
 */
function initial(string $name): string
{
    $name = trim($name);
    if ($name === '') {
        return '?';
    }
    return mb_strtoupper(mb_substr($name, 0, 1, 'UTF-8'), 'UTF-8');
}

/**
 * 状态中文名。
 */
function status_label(string $s): string
{
    return [
        'open'       => '待处理',
        'processing' => '处理中',
        'replied'    => '已回复',
        'closed'     => '已关闭',
    ][$s] ?? $s;
}

/**
 * 优先级中文名。
 */
function priority_label(string $p): string
{
    return ['low' => '低', 'normal' => '中', 'high' => '高'][$p] ?? $p;
}

/**
 * 生成站点绝对根地址（用于回调链接）。
 */
function base_url(): string
{
    $cfg = config()['app']['base_url'] ?? '';
    if ($cfg) {
        return rtrim($cfg, '/');
    }
    $https  = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    $scheme = $https ? 'https' : 'http';
    $host   = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $dir    = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');
    return $scheme . '://' . $host . $dir;
}

/**
 * 写站内通知。
 */
function add_notification(int $userId, ?int $ticketId, string $content, string $channel = 'inner'): void
{
    $st = db()->prepare(
        'INSERT INTO notifications (user_id, ticket_id, content, channel) VALUES (?, ?, ?, ?)'
    );
    $st->execute([$userId, $ticketId, $content, $channel]);
}

/**
 * 简单 JSON 响应。
 */
function json_out($data, int $code = 200): void
{
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

/**
 * 一次性提示（flash）。
 */
function flash_set(string $type, string $msg): void
{
    $_SESSION['flash'] = ['type' => $type, 'msg' => $msg];
}

function flash_take(): ?array
{
    if (empty($_SESSION['flash'])) {
        return null;
    }
    $f = $_SESSION['flash'];
    unset($_SESSION['flash']);
    return $f;
}

/**
 * CSRF token 生成与校验。
 */
function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(16));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="_csrf" value="' . e(csrf_token()) . '">';
}

function csrf_check(): void
{
    $t = $_POST['_csrf'] ?? '';
    if (!$t || empty($_SESSION['csrf']) || !hash_equals($_SESSION['csrf'], $t)) {
        http_response_code(419);
        exit('CSRF token 校验失败，请刷新页面重试。');
    }
}
