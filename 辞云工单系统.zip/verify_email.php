<?php
// verify_email.php — 邮箱绑定（验证）：输入 6 位验证码完成验证，未验证的客户无法使用业务功能
declare(strict_types=1);
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/mailer.php';

$u = require_login();
if ($u['role'] === 'agent') {
    header('Location: agent_dashboard.php');
    exit;
}
if (is_email_verified($u)) {
    header('Location: ticket_list.php');
    exit;
}

$errors = [];

/* ===== 重新发送验证码 ===== */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'resend') {
    csrf_check();
    $err = null;
    if (issue_verify_code((int)$u['id'], $err)) {
        flash_set('success', '验证码已发送至 ' . $u['email'] . '，请注意查收。');
    } else {
        flash_set('warn', '验证码已刷新，但邮件发送失败：' . $err . (mail_configured() ? '' : '（尚未配置邮件服务）'));
    }
    header('Location: verify_email.php');
    exit;
}

/* ===== 提交验证码 ===== */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'verify') {
    csrf_check();
    $code = trim((string)($_POST['code'] ?? ''));
    $st = db()->prepare('SELECT verify_code, verify_expires FROM users WHERE id = ? LIMIT 1');
    $st->execute([(int)$u['id']]);
    $row = $st->fetch();

    if ($code === '') {
        $errors[] = '请输入邮箱验证码。';
    } elseif (!$row || (string)$row['verify_code'] === '') {
        $errors[] = '尚未生成验证码，请点击「重新发送验证码」。';
    } elseif ($row['verify_expires'] && strtotime((string)$row['verify_expires']) < time()) {
        $errors[] = '验证码已过期，请点击「重新发送验证码」。';
    } elseif (!hash_equals((string)$row['verify_code'], $code)) {
        $errors[] = '验证码不正确，请重新输入。';
    } else {
        db()->prepare('UPDATE users SET email_verified_at = NOW(), verify_code = NULL, verify_expires = NULL WHERE id = ?')
            ->execute([(int)$u['id']]);
        flash_set('success', '邮箱验证成功，欢迎使用工单系统。');
        header('Location: ticket_list.php');
        exit;
    }
}

/* ===== 首次进入自动发放验证码 ===== */
$st = db()->prepare('SELECT verify_code, verify_expires FROM users WHERE id = ? LIMIT 1');
$st->execute([(int)$u['id']]);
$cur = $st->fetch();
$expired = !$cur || (string)$cur['verify_code'] === ''
    || ($cur['verify_expires'] && strtotime((string)$cur['verify_expires']) < time());
if ($expired) {
    $err = null;
    issue_verify_code((int)$u['id'], $err);
    $st->execute([(int)$u['id']]);
    $cur = $st->fetch();
}
$showCode = !mail_configured() ? (string)($cur['verify_code'] ?? '') : '';

$PAGE_TITLE = '验证邮箱';
$PAGE_LEAD  = '完成邮箱验证后即可使用工单系统';
include __DIR__ . '/header.php';
?>
<div class="auth-wrap">
  <div class="card">
    <h1 style="margin-top:0">验证你的邮箱</h1>
    <p class="muted">验证码将发送至 <strong class="mono"><?= e($u['email']) ?></strong>，30 分钟内有效。</p>

    <?php foreach ($errors as $err): ?>
      <div class="alert alert-danger"><?= e($err) ?></div>
    <?php endforeach; ?>

    <?php if (!mail_configured()): ?>
      <div class="alert alert-warn">
        邮件服务尚未配置。为便于调试，当前验证码直接显示：
        <span class="mono" style="font-size:20px;letter-spacing:4px"><?= e($showCode) ?></span><br>
        管理员可在「系统设置 → 邮件服务」中启用邮件发送；启用后验证码将仅通过邮件送达。
      </div>
    <?php endif; ?>

    <form method="post" novalidate class="mt8">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="verify">
      <div class="form-group">
        <label for="code">邮箱验证码</label>
        <input id="code" name="code" type="text" inputmode="numeric" maxlength="6" required
               class="mono" placeholder="6 位数字" autocomplete="one-time-code" autofocus
               style="letter-spacing:6px;font-size:20px">
      </div>
      <button class="btn btn-primary btn-block" type="submit">完成验证</button>
    </form>

    <form method="post" class="mt12">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="resend">
      <button class="btn btn-ghost btn-block" type="submit">重新发送验证码</button>
    </form>

    <p class="muted center mt16">
      邮箱填写有误？<a href="logout.php">退出登录</a>后使用正确邮箱重新注册
    </p>
  </div>
</div>
<?php include __DIR__ . '/footer.php'; ?>
