<?php
// index.php — 站点首页 / 统一入口：已登录按角色跳转，未登录展示落地页（修复根目录 403）
declare(strict_types=1);
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';

$u = current_user();
if ($u) {
    if ($u['role'] === 'agent') {
        header('Location: agent_dashboard.php');
    } elseif (empty($u['email_verified_at'])) {
        header('Location: verify_email.php');
    } else {
        header('Location: ticket_list.php');
    }
    exit;
}

$PAGE_TITLE = '首页';
include __DIR__ . '/header.php';
?>
<div class="auth-wrap">
  <div class="card center">
    <h1 style="margin-top:0">在线工单系统</h1>
    <p class="muted">遇到问题？提交工单，客服会尽快跟进处理。</p>
    <div class="flex gap8 wrap mt16" style="justify-content:center">
      <a class="btn btn-primary" href="login.php">登录</a>
      <a class="btn btn-ghost" href="register.php">注册账号</a>
    </div>
    <p class="muted mt16" style="font-size:13px">
      注册需完成邮箱验证；工单进度会同步到你的站内通知。
    </p>
  </div>
</div>
<?php include __DIR__ . '/footer.php'; ?>
