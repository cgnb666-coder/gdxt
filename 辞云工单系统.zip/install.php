<?php
// install.php — 安装向导（4 步）：环境检测 -> 数据库配置 -> 管理员账户 -> 完成
declare(strict_types=1);

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

$ROOT        = __DIR__;
$CONFIG_FILE = $ROOT . '/config.php';
$LOCK_FILE   = $ROOT . '/install.lock';
$SQL_FILE    = $ROOT . '/install.sql';
$COMPANY     = '示例科技有限公司'; // 可在安装后于「系统设置」中修改

/* ===== 已安装拦截 ===== */
$step = (int)($_GET['step'] ?? 1);
$busy = ($_SERVER['REQUEST_METHOD'] === 'POST');

if (is_file($LOCK_FILE) && $step < 4 && !$busy) {
    install_page('已安装', 4, function () use ($COMPANY): void {
        echo '<div class="card center"><div class="alert alert-warn">系统已安装。如需重装，请先删除根目录下的 <span class="mono">install.lock</span> 与 <span class="mono">config.php</span>。</div>';
        echo '<div class="flex gap8" style="justify-content:center"><a class="btn btn-primary" href="login.php">前往登录</a></div></div>';
    }, $COMPANY);
    exit;
}

/* ===== JSON：测试数据库连接 ===== */
if ($busy && ($_POST['action'] ?? '') === 'test_db') {
    header('Content-Type: application/json; charset=utf-8');
    [$ok, $msg] = test_connection(
        (string)($_POST['db_host'] ?? ''),
        (int)($_POST['db_port'] ?? 3306),
        (string)($_POST['db_name'] ?? ''),
        (string)($_POST['db_user'] ?? ''),
        (string)($_POST['db_pass'] ?? '')
    );
    echo json_encode(['ok' => $ok, 'message' => $msg], JSON_UNESCAPED_UNICODE);
    exit;
}

/* ===== 第 2 步提交：写库 + 生成 config.php ===== */
if ($busy && ($_POST['step'] ?? '') === '2') {
    $db = [
        'host' => trim((string)($_POST['db_host'] ?? '127.0.0.1')),
        'port' => (int)($_POST['db_port'] ?? 3306),
        'name' => trim((string)($_POST['db_name'] ?? '')),
        'user' => trim((string)($_POST['db_user'] ?? '')),
        'pass' => (string)($_POST['db_pass'] ?? ''),
    ];
    $error = null;
    if ($db['name'] === '' || $db['user'] === '') {
        $error = '请填写数据库名与用户名。';
    }
    if (!$error) {
        [$ok, $msg, $pdo] = connect_server($db['host'], $db['port'], $db['user'], $db['pass']);
        if (!$ok) {
            $error = '连接 MySQL 失败：' . $msg;
        } else {
            try {
                $pdo->exec("CREATE DATABASE IF NOT EXISTS `" . str_replace('`', '', $db['name']) . "` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
                $pdo->exec("USE `" . str_replace('`', '', $db['name']) . "`");
                run_sql_file($pdo, $SQL_FILE);

                $cfg = [
                    'db' => [
                        'host' => $db['host'], 'port' => $db['port'], 'name' => $db['name'],
                        'user' => $db['user'], 'pass' => $db['pass'], 'charset' => 'utf8mb4',
                    ],
                    'qq' => [
                        'app_id' => trim((string)($_SESSION['qq_app_id'] ?? '')),
                        'app_secret' => trim((string)($_SESSION['qq_app_secret'] ?? '')),
                        'client_secret' => trim((string)($_SESSION['qq_app_secret'] ?? '')),
                    ],
                    'app' => [
                        'name' => '工单系统',
                        'company' => $COMPANY,
                        'base_url' => '',
                        'proactive_monthly_limit' => 4,
                        'processing_inner_threshold' => 2,
                    ],
                ];
                $php = "<?php\n// config.php — 由安装向导自动生成，请勿随意泄露\nreturn " . var_export($cfg, true) . ";\n";
                if (@file_put_contents($CONFIG_FILE, $php) === false) {
                    $error = '写入 config.php 失败，请检查目录写权限。';
                }
            } catch (Throwable $ex) {
                $error = '初始化数据表失败：' . $ex->getMessage();
            }
        }
    }
    if ($error) {
        $_SESSION['install_error'] = $error;
        header('Location: install.php?step=2');
        exit;
    }
    @mkdir($ROOT . '/runtime', 0755, true);
    header('Location: install.php?step=3');
    exit;
}

/* ===== 第 3 步提交：创建管理员 + 生成 install.lock ===== */
if ($busy && ($_POST['step'] ?? '') === '3') {
    require_once $ROOT . '/db.php';

    $username = trim((string)($_POST['username'] ?? ''));
    $email    = trim((string)($_POST['email'] ?? ''));
    $pass     = (string)($_POST['password'] ?? '');
    $confirm  = (string)($_POST['password_confirm'] ?? '');
    $appId    = trim((string)($_POST['qq_app_id'] ?? ''));
    $appSec   = trim((string)($_POST['qq_app_secret'] ?? ''));

    $error = null;
    if (mb_strlen($username) < 2) { $error = '管理员用户名至少 2 个字符。'; }
    elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) { $error = '邮箱格式不正确。'; }
    elseif (strlen($pass) < 6) { $error = '密码至少 6 位。'; }
    elseif ($pass !== $confirm) { $error = '两次密码不一致。'; }

    if (!$error) {
        try {
            $st = db()->prepare('SELECT id FROM users WHERE email = ? LIMIT 1');
            $st->execute([$email]);
            if ($st->fetch()) {
                $error = '该邮箱已被使用。';
            } else {
                db()->prepare('INSERT INTO users (username, email, password_hash, role, avatar_color, email_verified_at, created_at)
                               VALUES (?, ?, ?, "agent", "#00e5ff", NOW(), NOW())')
                    ->execute([$username, $email, password_hash($pass, PASSWORD_DEFAULT)]);

                if ($appId !== '') { setting_set('qq_app_id', $appId); }
                if ($appSec !== '') {
                    setting_set('qq_app_secret', $appSec);
                    setting_set('qq_client_secret', $appSec);
                }
                @mkdir($ROOT . '/runtime', 0755, true);
                @file_put_contents($LOCK_FILE, "installed_at=" . date('c') . "\ncompany={$COMPANY}\n");
            }
        } catch (Throwable $ex) {
            $error = '创建管理员失败：' . $ex->getMessage();
        }
    }
    if ($error) {
        $_SESSION['install_error'] = $error;
        header('Location: install.php?step=3');
        exit;
    }
    header('Location: install.php?step=4');
    exit;
}

/* ===== 环境检测结果 ===== */
function env_checks(): array
{
    return [
        ['name' => 'PHP 版本 ≥ 8.0',   'ok' => version_compare(PHP_VERSION, '8.0.0', '>='), 'val' => PHP_VERSION],
        ['name' => 'PDO MySQL 扩展',    'ok' => extension_loaded('pdo_mysql'), 'val' => extension_loaded('pdo_mysql') ? '已启用' : '缺失'],
        ['name' => 'cURL 扩展',         'ok' => extension_loaded('curl'), 'val' => extension_loaded('curl') ? '已启用' : '缺失'],
        ['name' => '根目录可写',         'ok' => is_writable(__DIR__), 'val' => is_writable(__DIR__) ? '可写' : '不可写'],
        ['name' => 'Ed25519 签名能力',  'ok' => (extension_loaded('sodium') || extension_loaded('openssl')), 'val' => extension_loaded('sodium') ? 'Sodium 已启用' : (extension_loaded('openssl') ? 'OpenSSL 兜底（可用）' : '缺失（回调签名需要 sodium 或 openssl）')],
    ];
}

/* ================= 工具函数 ================= */
function connect_server(string $host, int $port, string $user, string $pass): array
{
    try {
        $pdo = new PDO("mysql:host={$host};port={$port};charset=utf8mb4", $user, $pass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_TIMEOUT => 6,
        ]);
        return [true, '连接成功', $pdo];
    } catch (Throwable $e) {
        return [false, $e->getMessage(), null];
    }
}

function test_connection(string $host, int $port, string $name, string $user, string $pass): array
{
    [$ok, $msg, $pdo] = connect_server($host, $port, $user, $pass);
    if (!$ok) {
        return [false, '无法连接：' . $msg];
    }
    $exists = false;
    try {
        $st = $pdo->prepare('SELECT SCHEMA_NAME FROM information_schema.SCHEMATA WHERE SCHEMA_NAME = ?');
        $st->execute([$name]);
        $exists = (bool)$st->fetch();
    } catch (Throwable $e) {
        // 忽略
    }
    return [true, $exists ? "连接成功，数据库 `{$name}` 已存在。" : "连接成功，数据库 `{$name}` 不存在，安装时将自动创建。"];
}

function run_sql_file(PDO $pdo, string $file): void
{
    $sql = (string)file_get_contents($file);
    // 去除 -- 注释行
    $sql = preg_replace('/^\s*--.*$/m', '', $sql);
    foreach (explode(';', $sql) as $stmt) {
        $stmt = trim($stmt);
        if ($stmt !== '') {
            $pdo->exec($stmt);
        }
    }
}

/**
 * 输出安装向导页面骨架。
 */
function install_page(string $title, int $step, callable $body, string $company): void
{
    $steps = ['环境检测', '数据库配置', '管理员账户', '完成安装'];
    ?><!DOCTYPE html>
<html lang="zh-CN"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= htmlspecialchars($title) ?> · 工单系统安装向导</title>
<link rel="stylesheet" href="assets/style.css">
</head><body class="layout-customer">
<div class="bg-decor" aria-hidden="true"></div>
<header class="site-header">
  <span class="brand">
    <span class="logo"><svg viewBox="0 0 48 48" fill="none"><defs><linearGradient id="lg" x1="0" y1="0" x2="48" y2="48"><stop stop-color="#00e5ff"/><stop offset="1" stop-color="#4d7cff"/></linearGradient></defs><path d="M24 4 40 12v14c0 9-7 16-16 18C15 42 8 35 8 26V12L24 4z" stroke="url(#lg)" stroke-width="2" fill="rgba(0,229,255,0.06)"/><path d="M17 24h5l3-7 3 14 3-7h4" stroke="url(#lg)" stroke-width="2.2" stroke-linecap="round"/></svg></span>
    <span class="brand-text"><strong>工单系统</strong><small>TICKET SYSTEM</small></span>
  </span>
  <div class="brand-company"><?= htmlspecialchars($company) ?></div>
</header>
<main class="container">
  <div class="wizard">
    <div class="steps">
      <?php foreach ($steps as $i => $label): $n = $i + 1; ?>
        <div class="step <?= $n === $step ? 'active' : ($n < $step ? 'done' : '') ?>">
          <div class="step-no"><?= $n < $step ? '✓' : $n ?></div>
          <div><?= htmlspecialchars($label) ?></div>
        </div>
      <?php endforeach; ?>
    </div>
    <?php $body(); ?>
  </div>
</main>
<footer class="site-footer">
  <div>© 2026 <?= htmlspecialchars($company) ?> 版权所有</div>
  <div class="icp">ICP备案号：待填写</div>
</footer>
</body></html><?php
}

/* ================= 渲染当前步骤 ================= */
if ($step === 1) {
    $checks   = env_checks();
    $allOk    = true;
    foreach ($checks as $c) { if (!$c['ok']) { $allOk = false; } }
    install_page('环境检测', 1, function () use ($checks, $allOk): void {
        echo '<div class="card"><h3 class="card-title"><span class="dot"></span>运行环境检测</h3><div class="check-list">';
        foreach ($checks as $c) {
            echo '<div class="check-item ' . ($c['ok'] ? 'ok' : 'fail') . '">'
               . '<span class="mark">' . ($c['ok'] ? '✓' : '✕') . '</span>'
               . '<span>' . htmlspecialchars($c['name']) . '</span>'
               . '<span class="val">' . htmlspecialchars((string)$c['val']) . '</span></div>';
        }
        echo '</div>';
        if ($allOk) {
            echo '<a class="btn btn-primary mt16" href="install.php?step=2">下一步：数据库配置</a>';
        } else {
            echo '<div class="alert alert-danger mt16">存在未通过项：请先解决「PDO MySQL / cURL / 目录写权限」等问题后再继续。</div>';
        }
        if (!$allOk) {
            echo '<a class="btn btn-ghost mt8" href="install.php?step=1">重新检测</a>';
        }
        echo '</div>';
    }, $COMPANY);
    exit;
}

if ($step === 2) {
    $err = $_SESSION['install_error'] ?? null;
    unset($_SESSION['install_error']);
    install_page('数据库配置', 2, function () use ($err, $COMPANY): void {
        if ($err) { echo '<div class="alert alert-danger">' . htmlspecialchars($err) . '</div>'; }
        ?>
        <div class="card">
          <h3 class="card-title"><span class="dot"></span>数据库配置</h3>
          <form method="post" id="dbForm">
            <input type="hidden" name="step" value="2">
            <div class="form-grid">
              <div class="form-group">
                <label for="db_host">主机</label>
                <input id="db_host" name="db_host" type="text" value="127.0.0.1" class="mono" required>
              </div>
              <div class="form-group">
                <label for="db_port">端口</label>
                <input id="db_port" name="db_port" type="number" value="3306" class="mono" required>
              </div>
              <div class="form-group">
                <label for="db_name">数据库名</label>
                <input id="db_name" name="db_name" type="text" value="ticket_system" class="mono" required>
              </div>
              <div class="form-group">
                <label for="db_user">用户名</label>
                <input id="db_user" name="db_user" type="text" value="root" class="mono" required>
              </div>
            </div>
            <div class="form-group">
              <label for="db_pass">密码</label>
              <input id="db_pass" name="db_pass" type="password" placeholder="数据库密码">
            </div>
            <div id="testDbResult" class="alert hide"></div>
            <div class="flex gap8 wrap">
              <button class="btn btn-ghost" type="button" id="testDbBtn">测试连接</button>
              <button class="btn btn-primary" type="submit">下一步：创建管理员</button>
            </div>
            <div class="form-hint mt8">提交后将：连接 MySQL → 不存在则创建库（utf8mb4）→ 执行 install.sql 建表 → 生成 config.php。</div>
          </form>
        </div>
        <?php
    }, $COMPANY);
    exit;
}

if ($step === 3) {
    $err = $_SESSION['install_error'] ?? null;
    unset($_SESSION['install_error']);
    install_page('管理员账户', 3, function () use ($err, $COMPANY): void {
        if ($err) { echo '<div class="alert alert-danger">' . htmlspecialchars($err) . '</div>'; }
        ?>
        <div class="card">
          <h3 class="card-title"><span class="dot"></span>创建管理员账户</h3>
          <form method="post">
            <input type="hidden" name="step" value="3">
            <div class="form-grid">
              <div class="form-group">
                <label for="username">管理员用户名</label>
                <input id="username" name="username" type="text" required placeholder="如 admin">
              </div>
              <div class="form-group">
                <label for="email">邮箱</label>
                <input id="email" name="email" type="email" required placeholder="admin@example.com">
              </div>
              <div class="form-group">
                <label for="password">密码</label>
                <input id="password" name="password" type="password" required placeholder="至少 6 位">
              </div>
              <div class="form-group">
                <label for="password_confirm">确认密码</label>
                <input id="password_confirm" name="password_confirm" type="password" required>
              </div>
            </div>

            <h3 class="card-title mt16"><span class="dot"></span>QQ 机器人（可选，可跳过）</h3>
            <div class="form-grid">
              <div class="form-group">
                <label for="qq_app_id">AppID</label>
                <input id="qq_app_id" name="qq_app_id" type="text" class="mono" placeholder="留空可稍后在系统设置填写">
              </div>
              <div class="form-group">
                <label for="qq_app_secret">AppSecret</label>
                <input id="qq_app_secret" name="qq_app_secret" type="text" class="mono" placeholder="可用于签名校验与获取 token">
              </div>
            </div>

            <div class="flex gap8 mt8">
              <button class="btn btn-primary" type="submit">完成安装</button>
              <a class="btn btn-ghost" href="install.php?step=2">上一步</a>
            </div>
          </form>
        </div>
        <?php
    }, $COMPANY);
    exit;
}

/* step 4：完成 */
install_page('完成安装', 4, function (): void {
    ?>
    <div class="card">
      <div class="alert alert-success">安装完成！已生成 <span class="mono">install.lock</span>，防止重复安装。</div>
      <h3 class="card-title"><span class="dot"></span>后续步骤</h3>
      <ol class="muted" style="padding-left:20px;line-height:2">
        <li>建议删除 <span class="mono">install.php</span>；或保留 <span class="mono">install.lock</span> 以阻止重装。</li>
        <li>站点首页为 <span class="mono">index.php</span>，请将域名根目录指向本项目。</li>
        <li>登录后台后在「系统设置 → 邮件服务」中配置 SMTP，客户注册需完成邮箱验证才能使用工单功能。</li>
        <li>如需 QQ 机器人通知（可选）：在开放平台配置回调地址 <span class="mono">https://你的域名/callback.php</span>，并订阅 FRIEND_ADD、C2C_MESSAGE_CREATE 等事件。</li>
      </ol>
      <div class="flex gap8 wrap mt16">
        <a class="btn btn-primary" href="login.php">前往登录</a>
        <a class="btn btn-ghost" href="install.php?step=1">回到检测页</a>
      </div>
    </div>
    <?php
}, $COMPANY);
exit;
