<?php
// agent_dashboard.php — 客服仪表盘：统计卡片 + 最近工单 + 状态分布 + 客服绩效
declare(strict_types=1);
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';

$u = require_agent();

$counts = ['open' => 0, 'processing' => 0, 'replied' => 0, 'closed' => 0];
foreach (db()->query('SELECT status, COUNT(*) c FROM tickets GROUP BY status') as $row) {
    $counts[$row['status']] = (int)$row['c'];
}
$total = array_sum($counts);
$today = (int)(db()->query('SELECT COUNT(*) c FROM tickets WHERE DATE(created_at) = CURDATE()')->fetch()['c'] ?? 0);

$recent = db()->query('SELECT t.*, u.username AS customer_name FROM tickets t
                       JOIN users u ON u.id = t.user_id
                       ORDER BY t.updated_at DESC LIMIT 8')->fetchAll();

$perf = db()->query(
    "SELECT a.id, a.username,
       (SELECT COUNT(*) FROM tickets t WHERE t.assigned_agent_id = a.id) AS assigned,
       (SELECT COUNT(*) FROM ticket_replies r WHERE r.user_id = a.id AND r.reply_type = 'agent') AS replies,
       (SELECT ROUND(AVG(TIMESTAMPDIFF(MINUTE, t.created_at, fr.first_at)))
          FROM tickets t
          JOIN (SELECT ticket_id, MIN(created_at) first_at FROM ticket_replies
                WHERE reply_type = 'agent' GROUP BY ticket_id) fr ON fr.ticket_id = t.id
         WHERE t.assigned_agent_id = a.id) AS avg_resp
     FROM users a WHERE a.role = 'agent' ORDER BY replies DESC"
)->fetchAll();

$maxCount = max(1, max($counts));

$IS_AGENT_LAYOUT = true;
$ACTIVE_MENU     = 'dashboard';
$PAGE_TITLE      = '仪表盘';
$BREADCRUMB      = ['控制台', '仪表盘'];
include __DIR__ . '/header.php';
?>
<div class="stats-grid">
  <div class="card stat-card">
    <div class="stat-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 5h16v4a2 2 0 0 0 0 4v4H4v-4a2 2 0 0 0 0-4V5z"/></svg></div>
    <div class="stat-value"><?= $total ?></div>
    <div class="stat-label">总工单</div>
    <div class="stat-sub">今日新增 <b>+<?= $today ?></b></div>
  </div>
  <div class="card stat-card p-warn">
    <div class="stat-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 8v5l3 2M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18z"/></svg></div>
    <div class="stat-value"><?= $counts['open'] ?></div>
    <div class="stat-label">待处理</div>
    <div class="stat-sub">需要尽快响应</div>
  </div>
  <div class="card stat-card p-purple">
    <div class="stat-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 3v3m0 12v3m9-9h-3M6 12H3m14.5-6.5-2 2m-7 7-2 2m11 0-2-2m-7-7-2-2"/></svg></div>
    <div class="stat-value"><?= $counts['processing'] ?></div>
    <div class="stat-label">处理中</div>
    <div class="stat-sub">正在跟进中</div>
  </div>
  <div class="card stat-card p-ok">
    <div class="stat-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M20 6 9 17l-5-5"/></svg></div>
    <div class="stat-value"><?= $counts['closed'] ?></div>
    <div class="stat-label">已完成</div>
    <div class="stat-sub">已回复 <b><?= $counts['replied'] ?></b></div>
  </div>
</div>

<div class="split mt16">
  <div class="split-left">
    <div class="card">
      <div class="between mb16">
        <h3 class="card-title" style="margin:0"><span class="dot"></span>最近工单</h3>
        <a class="btn btn-ghost btn-sm" href="agent_tickets.php">全部工单</a>
      </div>
      <div class="table-wrap">
        <table class="data-table responsive">
          <thead><tr><th>编号</th><th>标题</th><th>客户</th><th>状态</th><th>更新时间</th></tr></thead>
          <tbody>
          <?php foreach ($recent as $t): ?>
            <tr>
              <td data-label="编号" class="mono">#T<?= str_pad((string)$t['id'], 6, '0', STR_PAD_LEFT) ?></td>
              <td data-label="标题" class="title-cell"><a href="agent_ticket_detail.php?id=<?= (int)$t['id'] ?>"><?= e($t['title']) ?></a></td>
              <td data-label="客户"><?= e($t['customer_name']) ?></td>
              <td data-label="状态"><span class="badge badge-<?= e($t['status']) ?>"><?= e(status_label($t['status'])) ?></span></td>
              <td data-label="更新时间" class="mono"><?= e($t['updated_at']) ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>

    <div class="card">
      <h3 class="card-title"><span class="dot"></span>客服绩效</h3>
      <div class="table-wrap">
        <table class="data-table responsive">
          <thead><tr><th>客服</th><th>接单数</th><th>回复数</th><th>平均响应时间</th></tr></thead>
          <tbody>
          <?php if (!$perf): ?>
            <tr><td colspan="4" class="muted center">暂无客服数据</td></tr>
          <?php endif; ?>
          <?php foreach ($perf as $p): ?>
            <tr>
              <td data-label="客服" class="title-cell"><?= e($p['username']) ?></td>
              <td data-label="接单数" class="mono"><?= (int)$p['assigned'] ?></td>
              <td data-label="回复数" class="mono"><?= (int)$p['replies'] ?></td>
              <td data-label="平均响应时间" class="mono"><?= $p['avg_resp'] !== null ? (int)$p['avg_resp'] . ' 分钟' : '—' ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <aside class="split-right">
    <div class="card">
      <h3 class="card-title"><span class="dot"></span>状态分布</h3>
      <div class="chart-bars">
        <?php
        $dist = [
            'open'       => ['待处理', 'c-open'],
            'processing' => ['处理中', 'c-processing'],
            'replied'    => ['已回复', 'c-replied'],
            'closed'     => ['已关闭', 'c-closed'],
        ];
        foreach ($dist as $key => $info):
            $c = $counts[$key];
            $w = round($c / $maxCount * 100);
        ?>
          <div class="chart-row">
            <span class="chart-label"><?= e($info[0]) ?></span>
            <span class="chart-track"><span class="chart-fill <?= e($info[1]) ?>" style="width:<?= $w ?>%"></span></span>
            <span class="chart-val"><?= $c ?></span>
          </div>
        <?php endforeach; ?>
      </div>
    </div>

    <div class="card">
      <h3 class="card-title"><span class="dot"></span>快捷操作</h3>
      <div class="flex gap8 wrap">
        <a class="btn btn-ghost btn-sm" href="agent_tickets.php?status=open">处理待办</a>
        <a class="btn btn-ghost btn-sm" href="admin_users.php?role=customer">用户管理</a>
        <a class="btn btn-ghost btn-sm" href="admin_settings.php">系统设置</a>
      </div>
    </div>
  </aside>
</div>
<?php include __DIR__ . '/footer.php'; ?>
