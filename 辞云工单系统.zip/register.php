<?php
// register.php — 客户注册（注册后强制跳转邮箱验证）
declare(strict_types=1);
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/mailer.php';

if (current_user()) {
    header('Location: ' . (current_user()['role'] === 'agent' ? 'agent_dashboard.php' : 'ticket_list.php'));
    exit;
}

$errors = [];
$old = ['username' => '', 'email' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $old['username'] = trim((string)($_POST['username'] ?? ''));
    $old['email']    = trim((string)($_POST['email'] ?? ''));
    $pass    = (string)($_POST['password'] ?? '');
    $confirm = (string)($_POST['password_confirm'] ?? '');

    if ($old['username'] === '' || mb_strlen($old['username']) < 2) {
        $errors[] = '请输入至少 2 个字符的用户名。';
    }
    if (!filter_var($old['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = '请输入有效的邮箱地址。';
    }
    if (strlen($pass) < 6) {
        $errors[] = '密码长度至少 6 位。';
    }
    if ($pass !== $confirm) {
        $errors[] = '两次输入的密码不一致。';
    }

    if (!$errors) {
        $st = db()->prepare('SELECT id FROM users WHERE email = ? LIMIT 1');
        $st->execute([$old['email']]);
        if ($st->fetch()) {
            $errors[] = '该邮箱已被注册。';
        }
    }

    if (!$errors) {
        $palette = ['#00e5ff', '#7c4dff', '#00e676', '#ff9100', '#ff5252', '#4a9eff'];
        $color   = $palette[array_rand($palette)];
        $st = db()->prepare('INSERT INTO users (username, email, password_hash, role, avatar_color, created_at)
                             VALUES (?, ?, ?, "customer", ?, NOW())');
        $st->execute([
            $old['username'],
            $old['email'],
            password_hash($pass, PASSWORD_DEFAULT),
            $color,
        ]);
        $_SESSION['uid'] = (int)db()->lastInsertId();
        // 生成并发送邮箱验证码（未配置邮件服务时验证页会直接展示验证码兜底）
        $mailErr = null;
        issue_verify_code((int)$_SESSION['uid'], $mailErr);
        flash_set('success', '注册成功，请查收邮件完成邮箱验证。');
        header('Location: verify_email.php');
        exit;
    }
}

$PAGE_TITLE = '注册账号';
include __DIR__ . '/header.php';
?>
<div class="auth-wrap">
  <div class="card">
    <h1>创建账号</h1>
    <p class="muted mb16">注册后需完成邮箱验证才能创建工单。</p>

    <?php foreach ($errors as $err): ?>
      <div class="alert alert-danger"><?= e($err) ?></div>
    <?php endforeach; ?>

    <form method="post" novalidate>
      <?= csrf_field() ?>
      <div class="form-group">
        <label for="username">用户名</label>
        <input id="username" name="username" type="text" required value="<?= e($old['username']) ?>" placeholder="请输入用户名">
      </div>
      <div class="form-group">
        <label for="email">邮箱</label>
        <input id="email" name="email" type="email" required value="<?= e($old['email']) ?>" placeholder="name@example.com">
      </div>
      <div class="form-group">
        <label for="password">密码</label>
        <input id="password" name="password" type="password" required placeholder="至少 6 位">
      </div>
      <div class="form-group">
        <label for="password_confirm">确认密码</label>
        <input id="password_confirm" name="password_confirm" type="password" required placeholder="再次输入密码">
      </div>
      <button class="btn btn-primary btn-block" type="submit">注册并验证邮箱</button>
    </form>
    <p class="muted center mt16">已有账号？<a href="login.php">立即登录</a></p>
  </div>
</div>
<?php include __DIR__ . '/footer.php'; ?>
