<?php
// ticket_list.php — 客户工单列表（状态筛选 + 搜索 + 分页，移动端卡片化）
declare(strict_types=1);
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';

$u = require_login();
if ($u['role'] === 'agent') {
    header('Location: agent_tickets.php');
    exit;
}
require_email_verified(); // 未验证邮箱 -> verify_email.php

$status = (string)($_GET['status'] ?? 'all');
$kw     = trim((string)($_GET['q'] ?? ''));
$page   = max(1, (int)($_GET['page'] ?? 1));
$per    = 10;
$offset = ($page - 1) * $per;

$where  = ['user_id = ?'];
$params = [(int)$u['id']];
if (in_array($status, ['open', 'processing', 'replied', 'closed'], true)) {
    $where[] = 'status = ?';
    $params[] = $status;
}
if ($kw !== '') {
    $where[] = '(title LIKE ? OR description LIKE ? OR uuid LIKE ?)';
    $like = '%' . $kw . '%';
    array_push($params, $like, $like, $like);
}
$whereSql = implode(' AND ', $where);

$cnt = db()->prepare("SELECT COUNT(*) c FROM tickets WHERE $whereSql");
$cnt->execute($params);
$total = (int)($cnt->fetch()['c'] ?? 0);
$pages = max(1, (int)ceil($total / $per));

$st = db()->prepare("SELECT t.*, (SELECT COUNT(*) FROM ticket_replies r WHERE r.ticket_id = t.id) AS reply_count
                     FROM tickets t WHERE $whereSql ORDER BY t.updated_at DESC LIMIT $per OFFSET $offset");
$st->execute($params);
$tickets = $st->fetchAll();

$statusTabs = [
    'all'        => '全部',
    'open'       => '待处理',
    'processing' => '处理中',
    'replied'    => '已回复',
    'closed'     => '已关闭',
];

$PAGE_TITLE = '我的工单';
$PAGE_LEAD  = '共 ' . $total . ' 个工单';
include __DIR__ . '/header.php';
?>
<div class="flex gap8 wrap mb16">
  <a class="tab <?= $status === 'all' ? '' : '' ?>" href="ticket_list.php">全部</a>
  <a class="tab" href="ticket_create.php">+ 创建工单</a>
  <div style="flex:1"></div>
</div>

<div class="card">
  <div class="table-toolbar">
    <div class="filter-tabs">
      <?php foreach ($statusTabs as $key => $label): ?>
        <a class="tab <?= $status === $key ? 'active' : '' ?>"
           href="ticket_list.php?status=<?= e($key) ?><?= $kw !== '' ? '&q=' . urlencode($kw) : '' ?>"><?= e($label) ?></a>
      <?php endforeach; ?>
    </div>
    <form class="search-box" method="get" style="margin-left:auto;max-width:280px">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>
      <input type="search" name="q" value="<?= e($kw) ?>" placeholder="搜索标题 / 编号">
      <?php if ($status !== 'all'): ?><input type="hidden" name="status" value="<?= e($status) ?>"><?php endif; ?>
    </form>
  </div>

  <?php if (!$tickets): ?>
    <div class="empty">
      <div>暂无工单</div>
      <a class="btn btn-primary mt16" href="ticket_create.php">创建第一个工单</a>
    </div>
  <?php else: ?>
    <div class="table-wrap">
      <table class="data-table responsive">
        <thead>
          <tr>
            <th>编号</th><th>标题</th><th>状态</th><th>优先级</th><th>回复</th><th>更新时间</th><th>操作</th>
          </tr>
        </thead>
        <tbody>
        <?php foreach ($tickets as $t): ?>
          <tr>
            <td data-label="编号" class="mono">#T<?= str_pad((string)$t['id'], 6, '0', STR_PAD_LEFT) ?></td>
            <td data-label="标题" class="title-cell"><?= e($t['title']) ?></td>
            <td data-label="状态"><span class="badge badge-<?= e($t['status']) ?>"><?= e(status_label($t['status'])) ?></span></td>
            <td data-label="优先级"><span class="badge badge-<?= e($t['priority']) ?>"><?= e(priority_label($t['priority'])) ?></span></td>
            <td data-label="回复" class="mono"><?= (int)$t['reply_count'] ?></td>
            <td data-label="更新时间" class="mono"><?= e($t['updated_at']) ?></td>
            <td data-label="操作">
              <a class="btn btn-ghost btn-sm" href="ticket_detail.php?id=<?= (int)$t['id'] ?>">查看</a>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <?php if ($pages > 1): ?>
      <nav class="pagination">
        <a class="page-item <?= $page <= 1 ? 'disabled' : '' ?>"
           href="?status=<?= e($status) ?>&q=<?= urlencode($kw) ?>&page=<?= max(1, $page - 1) ?>">上一页</a>
        <?php for ($i = 1; $i <= $pages; $i++): ?>
          <a class="page-item <?= $i === $page ? 'active' : '' ?>"
             href="?status=<?= e($status) ?>&q=<?= urlencode($kw) ?>&page=<?= $i ?>"><?= $i ?></a>
        <?php endfor; ?>
        <a class="page-item <?= $page >= $pages ? 'disabled' : '' ?>"
           href="?status=<?= e($status) ?>&q=<?= urlencode($kw) ?>&page=<?= min($pages, $page + 1) ?>">下一页</a>
      </nav>
    <?php endif; ?>
  <?php endif; ?>
</div>
<?php include __DIR__ . '/footer.php'; ?>
