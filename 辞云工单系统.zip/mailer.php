<?php
// mailer.php — 内置 SMTP 客户端（无需任何外部库）：支持 SSL / STARTTLS / AUTH LOGIN，
//              用于发送邮箱验证码等系统邮件。配置项读写自 settings 表（系统设置 → 邮件服务）。
declare(strict_types=1);

require_once __DIR__ . '/db.php';

/**
 * 读取邮件配置：settings 表优先，回退 config.php 的 mail 段。
 */
function mail_conf(): array
{
    $c = config()['mail'] ?? [];
    return [
        'enabled'   => (string)setting_get('mail_enabled', !empty($c['enabled']) ? '1' : '0') === '1',
        'host'      => (string)setting_get('mail_host', $c['host'] ?? ''),
        'port'      => (int)setting_get('mail_port', (string)($c['port'] ?? 465)),
        'secure'    => (string)setting_get('mail_secure', $c['secure'] ?? 'ssl'), // ssl | tls | none
        'user'      => (string)setting_get('mail_user', $c['user'] ?? ''),
        'pass'      => (string)setting_get('mail_pass', $c['pass'] ?? ''),
        'from'      => (string)setting_get('mail_from', $c['from'] ?? ''),
        'from_name' => (string)setting_get('mail_from_name', $c['from_name'] ?? (config()['app']['name'] ?? '工单系统')),
    ];
}

/**
 * 邮件是否已配置可用（启用且填了服务器与发件地址）。
 */
function mail_configured(): bool
{
    $m = mail_conf();
    return $m['enabled'] && $m['host'] !== '' && $m['from'] !== '';
}

/**
 * MIME 编码主题（UTF-8 Base64）。
 */
function _mail_b64(string $s): string
{
    return '=?UTF-8?B?' . base64_encode($s) . '?=';
}

/**
 * 底层 SMTP 发送。成功返回 true，失败返回 false 并通过 $err 回传原因。
 */
function smtp_send(string $to, string $subject, string $html, ?string &$err = null): bool
{
    $m = mail_conf();
    if (!mail_configured()) {
        $err = '邮件服务未配置（请在「系统设置 → 邮件服务」中启用并填写）';
        return false;
    }
    if (!filter_var($to, FILTER_VALIDATE_EMAIL)) {
        $err = '收件地址不合法';
        return false;
    }

    $host   = $m['host'];
    $port   = $m['port'];
    $secure = strtolower($m['secure']);
    $scheme = $secure === 'ssl' ? 'ssl://' : '';

    $ctx = stream_context_create(['ssl' => [
        'verify_peer'      => true,
        'verify_peer_name' => true,
        'allow_self_signed' => false,
        'SNI_enabled'      => true,
        'peer_name'        => $host,
    ]]);
    $fp = @stream_socket_client($scheme . $host . ':' . $port, $errno, $errstr, 15, STREAM_CLIENT_CONNECT, $ctx);
    if (!$fp) {
        $err = "无法连接 {$host}:{$port}（{$errstr}）";
        return false;
    }
    stream_set_timeout($fp, 15);

    $read = static function () use ($fp): string {
        $data = '';
        while (($line = fgets($fp, 2048)) !== false) {
            $data .= $line;
            if (strlen($line) < 4 || $line[3] !== '-') {
                break; // 多行响应续行以 "250-" 表示
            }
        }
        return $data;
    };
    $cmd  = static function (string $c) use ($fp, $read): string {
        fwrite($fp, $c . "\r\n");
        return $read();
    };
    $code = static function (string $resp): int {
        return (int)substr($resp, 0, 3);
    };
    $fail = static function (string $msg) use ($fp, &$err): bool {
        $err = $msg;
        @fclose($fp);
        return false;
    };

    if ($code($read()) !== 220) {
        return $fail('SMTP 握手失败');
    }

    $hello   = gethostname() ?: 'localhost';
    $ehlo    = $cmd('EHLO ' . $hello);
    if ($code($ehlo) !== 250) {
        $ehlo = $cmd('HELO ' . $hello);
    }
    if ($code($ehlo) !== 250) {
        return $fail('EHLO/HELO 被拒绝');
    }

    if ($secure === 'tls') {
        $r = $cmd('STARTTLS');
        if ($code($r) !== 220) {
            return $fail('STARTTLS 被拒绝：' . trim($r));
        }
        if (!@stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) {
            return $fail('TLS 加密协商失败');
        }
        $cmd('EHLO ' . $hello);
    }

    if ($m['user'] !== '') {
        $r = $cmd('AUTH LOGIN');
        if ($code($r) !== 334) {
            return $fail('服务器不支持 AUTH LOGIN：' . trim($r));
        }
        $r = $cmd(base64_encode($m['user']));
        if ($code($r) !== 334) {
            return $fail('用户名被拒绝：' . trim($r));
        }
        $r = $cmd(base64_encode($m['pass']));
        if ($code($r) !== 235) {
            return $fail('认证失败，请检查账号/授权码：' . trim($r));
        }
    }

    $from = $m['from'] !== '' ? $m['from'] : $m['user'];
    if ($code($cmd('MAIL FROM:<' . $from . '>')) !== 250) {
        return $fail('MAIL FROM 被拒绝');
    }
    if (!in_array($code($cmd('RCPT TO:<' . $to . '>')), [250, 251], true)) {
        return $fail('收件人被拒绝');
    }
    if ($code($cmd('DATA')) !== 354) {
        return $fail('DATA 被拒绝');
    }

    $headers = [
        'From: ' . _mail_b64($m['from_name']) . ' <' . $from . '>',
        'To: <' . $to . '>',
        'Subject: ' . _mail_b64($subject),
        'MIME-Version: 1.0',
        'Content-Type: text/html; charset=UTF-8',
        'Content-Transfer-Encoding: base64',
        'Date: ' . date('r'),
        'Message-ID: <' . bin2hex(random_bytes(12)) . '@' . preg_replace('/[^a-z0-9.\-]/i', '', $host) . '>',
    ];
    $payload = implode("\r\n", $headers) . "\r\n\r\n" . chunk_split(base64_encode($html), 76, "\r\n") . '.';
    fwrite($fp, $payload . "\r\n");

    $resp = $read();
    @fclose($fp);
    if ($code($resp) !== 250) {
        $err = '发送被拒绝：' . trim($resp);
        return false;
    }
    return true;
}

/**
 * 生成 6 位数字验证码并写入用户记录（30 分钟有效），随后发送邮件。
 * 邮件未配置/发送失败时返回 false，但不影响验证码写入（验证页会直接展示以兜底）。
 */
function issue_verify_code(int $userId, ?string &$err = null): bool
{
    $code = str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT);
    db()->prepare('UPDATE users SET verify_code = ?, verify_expires = DATE_ADD(NOW(), INTERVAL 30 MINUTE) WHERE id = ?')
        ->execute([$code, $userId]);

    $st = db()->prepare('SELECT username, email FROM users WHERE id = ? LIMIT 1');
    $st->execute([$userId]);
    $u = $st->fetch();
    if (!$u) {
        $err = '用户不存在';
        return false;
    }
    if (!mail_configured()) {
        $err = '邮件服务未配置';
        return false;
    }
    return smtp_send((string)$u['email'], '【' . mail_conf()['from_name'] . '】邮箱验证码', mail_code_html($code, (string)$u['username']), $err);
}

/**
 * 验证码邮件正文（HTML）。
 */
function mail_code_html(string $code, string $username): string
{
    $app = e(mail_conf()['from_name']);
    $who = e($username);
    return '<div style="font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;max-width:520px;margin:0 auto;padding:24px;color:#111">'
        . '<h2 style="margin:0 0 12px">' . $app . '</h2>'
        . '<p>' . $who . ' 你好，</p>'
        . '<p>你正在验证邮箱，请在页面中输入以下验证码（30 分钟内有效）：</p>'
        . '<p style="font-size:32px;font-weight:700;letter-spacing:8px;color:#00b8d4;margin:20px 0">' . e($code) . '</p>'
        . '<p style="color:#888;font-size:13px">如果这不是你本人的操作，请忽略本邮件。</p>'
        . '</div>';
}

/**
 * 管理员通知邮箱（支持逗号/分号分隔多个）。
 */
function notify_admin_emails(): array
{
    $raw = (string)setting_get('notify_admin_email', config()['mail']['admin_to'] ?? '');
    $list = preg_split('/[,;，；\s]+/u', $raw, -1, PREG_SPLIT_NO_EMPTY) ?: [];
    $out = [];
    foreach ($list as $addr) {
        if (filter_var($addr, FILTER_VALIDATE_EMAIL)) {
            $out[] = $addr;
        }
    }
    return array_values(array_unique($out));
}

/**
 * 工单事件邮件通知：同时通知客户与管理员（管理员邮箱未配置则跳过）。
 * $event: created | processing | replied | closed | customer_reply | agent_reply
 *
 * @return array{customer:bool, admin:int, error:?string}
 */
function email_notify_ticket(int $ticketId, string $event, string $actor = ''): array
{
    $result = ['customer' => false, 'admin' => 0, 'error' => null];
    if (!mail_configured()) {
        $result['error'] = '邮件服务未配置';
        return $result;
    }

    $st = db()->prepare('SELECT t.*, u.username AS customer_name, u.email AS customer_email
                         FROM tickets t JOIN users u ON u.id = t.user_id WHERE t.id = ? LIMIT 1');
    $st->execute([$ticketId]);
    $t = $st->fetch();
    if (!$t) {
        $result['error'] = '工单不存在';
        return $result;
    }

    $short = '#T' . str_pad((string)$t['id'], 6, '0', STR_PAD_LEFT);
    $base  = rtrim(base_url(), '/');

    // 客户侧文案
    $custNote = [
        'created'        => '你的工单已提交，客服会尽快处理。',
        'processing'     => '客服已接单，正在处理中。',
        'replied'        => '客服已回复，请登录系统查看详情并回复。',
        'closed'         => '工单已关闭，感谢你的反馈。',
        'customer_reply' => '你的回复已提交，客服会尽快处理。',
        'agent_reply'    => '客服已回复，请登录系统查看详情并回复。',
    ][$event] ?? ('工单状态已更新为「' . status_label((string)$t['status']) . '」。');

    // 管理员侧文案（仅管理员关心的事件才发送）
    $adminNote = [
        'created'        => '有新的工单提交，请及时处理。',
        'processing'     => '工单状态已更新为「处理中」。',
        'replied'        => '工单状态已更新为「已回复」。',
        'closed'         => '工单已关闭。',
        'customer_reply' => '客户在工单中追加了回复，请及时处理。',
        'agent_reply'    => '客服已回复该工单。',
    ][$event] ?? null;

    $err = null;
    if ($result['error'] === null) {
        // 通知客户
        $custTo = (string)($t['customer_email'] ?? '');
        if (filter_var($custTo, FILTER_VALIDATE_EMAIL)) {
            $link = $base . '/ticket_detail.php?id=' . (int)$t['id'];
            $subject = '【' . mail_conf()['from_name'] . '】工单 ' . $short . ' ' . ticket_event_title($event);
            $result['customer'] = smtp_send($custTo, $subject, ticket_mail_html($t, $short, $custNote, $link, false, $actor), $err);
        }
        // 通知管理员
        if ($adminNote !== null) {
            $link = $base . '/agent_ticket_detail.php?id=' . (int)$t['id'];
            $subject = '【工单提醒】' . $short . ' ' . ticket_event_title($event) . '：' . mb_substr((string)$t['title'], 0, 40);
            foreach (notify_admin_emails() as $to) {
                if ($to === ($t['customer_email'] ?? '')) {
                    continue;
                }
                if (smtp_send($to, $subject, ticket_mail_html($t, $short, $adminNote, $link, true, $actor), $err)) {
                    $result['admin']++;
                }
            }
        }
    }
    if (!$result['customer'] && $result['admin'] === 0 && $err) {
        $result['error'] = $err;
    }
    return $result;
}

/**
 * 事件标题短语。
 */
function ticket_event_title(string $event): string
{
    return [
        'created'        => '已提交',
        'processing'     => '正在处理中',
        'replied'        => '已回复',
        'closed'         => '已关闭',
        'customer_reply' => '有新的客户回复',
        'agent_reply'    => '已回复',
    ][$event] ?? '状态更新';
}

/**
 * 工单通知邮件正文（HTML）。
 */
function ticket_mail_html(array $t, string $short, string $note, string $link, bool $forAdmin, string $actor): string
{
    $app   = e(mail_conf()['from_name']);
    $badge = ['open' => '待处理', 'processing' => '处理中', 'replied' => '已回复', 'closed' => '已关闭'][$t['status']] ?? $t['status'];
    $prio  = ['low' => '低', 'normal' => '中', 'high' => '高'][$t['priority']] ?? $t['priority'];
    $who   = $forAdmin ? '管理员' : (e((string)$t['customer_name']) . ' 你好');
    $desc  = mb_substr((string)$t['description'], 0, 200);
    return '<div style="font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;max-width:560px;margin:0 auto;padding:24px;color:#111">'
        . '<h2 style="margin:0 0 4px">' . $app . '</h2>'
        . '<p style="color:#888;font-size:13px;margin:0 0 16px">工单提醒</p>'
        . '<p>' . $who . '：</p>'
        . '<p>' . e($note) . ($actor !== '' ? '（操作人：' . e($actor) . '）' : '') . '</p>'
        . '<table style="width:100%;border-collapse:collapse;margin:16px 0;font-size:14px">'
        . '<tr><td style="padding:8px;border:1px solid #eee;background:#fafafa;width:90px">工单编号</td><td style="padding:8px;border:1px solid #eee">' . e($short) . '</td></tr>'
        . '<tr><td style="padding:8px;border:1px solid #eee;background:#fafafa">标题</td><td style="padding:8px;border:1px solid #eee">' . e((string)$t['title']) . '</td></tr>'
        . '<tr><td style="padding:8px;border:1px solid #eee;background:#fafafa">当前状态</td><td style="padding:8px;border:1px solid #eee">' . e($badge) . '</td></tr>'
        . '<tr><td style="padding:8px;border:1px solid #eee;background:#fafafa">优先级</td><td style="padding:8px;border:1px solid #eee">' . e($prio) . '</td></tr>'
        . '<tr><td style="padding:8px;border:1px solid #eee;background:#fafafa">问题描述</td><td style="padding:8px;border:1px solid #eee">' . e($desc) . '</td></tr>'
        . '</table>'
        . '<p><a href="' . e($link) . '" style="display:inline-block;background:#00b8d4;color:#fff;text-decoration:none;padding:10px 18px;border-radius:6px">查看工单详情</a></p>'
        . '<p style="color:#aaa;font-size:12px;margin-top:20px">本邮件由系统自动发送，请勿直接回复。</p>'
        . '</div>';
}
