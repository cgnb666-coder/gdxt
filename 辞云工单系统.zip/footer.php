<?php
// footer.php — 全站公共底部（含版权、ICP、脚本引入，footer 贴底）
declare(strict_types=1);
$__company = $__company ?? (config()['app']['company'] ?? '示例科技有限公司');
?>
<?php if (!empty($IS_AGENT_LAYOUT)): ?>
    </div><!-- /.content -->
  </div><!-- /.main -->
</div><!-- /.app-shell -->
<?php else: ?>
</main><!-- /.container -->
<?php endif; ?>

<footer class="site-footer">
  <div>© 2026 <?= e($__company) ?> 版权所有</div>
  <div class="icp">ICP备案号：待填写</div>
</footer>
<script src="assets/app.js"></script>
</body>
</html>
