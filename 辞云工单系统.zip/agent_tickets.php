<?php
// agent_tickets.php — 客服工单管理：状态/优先级筛选、搜索、批量操作、分页
declare(strict_types=1);
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/qq_send.php';

$u = require_agent();

/* ===== 批量操作 ===== */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = (string)($_POST['bulk_action'] ?? '');
    $ids    = array_values(array_filter(array_map('intval', (array)($_POST['ids'] ?? []))));
    if ($ids && in_array($action, ['accept', 'close'], true)) {
        $status = $action === 'accept' ? 'processing' : 'closed';
        $note   = $action === 'accept' ? '客服批量接单，正在处理。' : '工单已关闭。';
        foreach ($ids as $id) {
            $st = db()->prepare('SELECT assigned_agent_id FROM tickets WHERE id = ? LIMIT 1');
            $st->execute([$id]);
            $row = $st->fetch();
            if (!$row) { continue; }
            $assign = $action === 'accept' ? (int)$u['id'] : ($row['assigned_agent_id'] ?: (int)$u['id']);
            db()->prepare('UPDATE tickets SET status = ?, assigned_agent_id = ?, updated_at = NOW() WHERE id = ?')
                ->execute([$status, $assign, $id]);
            db()->prepare('INSERT INTO ticket_replies (ticket_id, user_id, content, reply_type, created_at)
                           VALUES (?, ?, ?, "system", NOW())')->execute([$id, (int)$u['id'], $note]);
            qq_notify_ticket($id, $status, (string)$u['username']);
        }
        flash_set('success', '已对 ' . count($ids) . ' 个工单执行「' . ($action === 'accept' ? '接单' : '关闭') . '」。');
    } else {
        flash_set('danger', '请先选择工单与操作。');
    }
    $q = http_build_query(array_filter([
        'status' => $_POST['f_status'] ?? 'all',
        'priority' => $_POST['f_priority'] ?? 'all',
        'q' => $_POST['f_q'] ?? '',
    ]));
    header('Location: agent_tickets.php' . ($q ? '?' . $q : ''));
    exit;
}

/* ===== 查询条件 ===== */
$status   = (string)($_GET['status'] ?? 'all');
$priority = (string)($_GET['priority'] ?? 'all');
$kw       = trim((string)($_GET['q'] ?? ''));
$page     = max(1, (int)($_GET['page'] ?? 1));
$per      = 12;
$offset   = ($page - 1) * $per;

$where  = ['1=1'];
$params = [];
if (in_array($status, ['open', 'processing', 'replied', 'closed'], true)) {
    $where[] = 't.status = ?';
    $params[] = $status;
}
if (in_array($priority, ['low', 'normal', 'high'], true)) {
    $where[] = 't.priority = ?';
    $params[] = $priority;
}
if ($kw !== '') {
    $where[] = '(t.title LIKE ? OR t.uuid LIKE ? OR u.username LIKE ?)';
    $like = '%' . $kw . '%';
    array_push($params, $like, $like, $like);
}
$whereSql = implode(' AND ', $where);

$cnt = db()->prepare("SELECT COUNT(*) c FROM tickets t JOIN users u ON u.id = t.user_id WHERE $whereSql");
$cnt->execute($params);
$total = (int)($cnt->fetch()['c'] ?? 0);
$pages = max(1, (int)ceil($total / $per));

$st = db()->prepare("SELECT t.*, u.username AS customer_name, a.username AS agent_name
                     FROM tickets t
                     JOIN users u ON u.id = t.user_id
                     LEFT JOIN users a ON a.id = t.assigned_agent_id
                     WHERE $whereSql ORDER BY t.updated_at DESC LIMIT $per OFFSET $offset");
$st->execute($params);
$tickets = $st->fetchAll();

$statusTabs = ['all' => '全部', 'open' => '待处理', 'processing' => '处理中', 'replied' => '已回复', 'closed' => '已关闭'];
$activeMap  = ['all' => 'tickets', 'open' => 'tickets_open', 'processing' => 'tickets_processing', 'replied' => 'tickets_replied', 'closed' => 'tickets_closed'];

$IS_AGENT_LAYOUT = true;
$ACTIVE_MENU     = $activeMap[$status] ?? 'tickets';
$PAGE_TITLE      = '工单管理';
$BREADCRUMB      = ['工单管理', $statusTabs[$status] ?? '全部'];
include __DIR__ . '/header.php';
?>
<div class="card">
  <form method="get" class="table-toolbar" id="filterForm">
    <div class="filter-tabs">
      <?php foreach ($statusTabs as $key => $label): ?>
        <a class="tab <?= $status === $key ? 'active' : '' ?>"
           href="?status=<?= e($key) ?>&priority=<?= e($priority) ?>&q=<?= urlencode($kw) ?>"><?= e($label) ?></a>
      <?php endforeach; ?>
    </div>
    <select name="priority" style="max-width:130px" onchange="this.form.submit()">
      <option value="all" <?= $priority === 'all' ? 'selected' : '' ?>>全部优先级</option>
      <option value="high" <?= $priority === 'high' ? 'selected' : '' ?>>高</option>
      <option value="normal" <?= $priority === 'normal' ? 'selected' : '' ?>>中</option>
      <option value="low" <?= $priority === 'low' ? 'selected' : '' ?>>低</option>
    </select>
    <input type="hidden" name="status" value="<?= e($status) ?>">
    <div class="search-box" style="margin-left:auto;max-width:260px">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>
      <input type="search" name="q" value="<?= e($kw) ?>" placeholder="搜索编号 / 标题 / 客户">
    </div>
    <button class="btn btn-ghost btn-sm" type="submit">搜索</button>
  </form>

  <form method="post" id="bulkForm">
    <?= csrf_field() ?>
    <input type="hidden" name="f_status" value="<?= e($status) ?>">
    <input type="hidden" name="f_priority" value="<?= e($priority) ?>">
    <input type="hidden" name="f_q" value="<?= e($kw) ?>">
    <div class="flex between mb16 hide" id="bulkBar">
      <span class="muted">已选择 <b id="bulkCount">0</b> 项</span>
      <div class="flex gap8">
        <button class="btn btn-ghost btn-sm" name="bulk_action" value="accept" type="submit">批量接单</button>
        <button class="btn btn-danger btn-sm" name="bulk_action" value="close" type="submit"
                data-confirm="确定关闭所选工单？">批量关闭</button>
      </div>
    </div>

    <?php if (!$tickets): ?>
      <div class="empty">没有符合条件的工单</div>
    <?php else: ?>
      <div class="table-wrap">
        <table class="data-table responsive">
          <thead>
            <tr>
              <th style="width:36px"><input type="checkbox" id="checkAll"></th>
              <th>编号</th><th>标题</th><th>客户</th><th>优先级</th><th>状态</th><th>处理客服</th><th>更新时间</th><th>操作</th>
            </tr>
          </thead>
          <tbody>
          <?php foreach ($tickets as $t): ?>
            <tr>
              <td data-label="选择"><input type="checkbox" class="row-check" name="ids[]" value="<?= (int)$t['id'] ?>"></td>
              <td data-label="编号" class="mono">#T<?= str_pad((string)$t['id'], 6, '0', STR_PAD_LEFT) ?></td>
              <td data-label="标题" class="title-cell"><a href="agent_ticket_detail.php?id=<?= (int)$t['id'] ?>"><?= e($t['title']) ?></a></td>
              <td data-label="客户"><?= e($t['customer_name']) ?></td>
              <td data-label="优先级"><span class="badge badge-<?= e($t['priority']) ?>"><?= e(priority_label($t['priority'])) ?></span></td>
              <td data-label="状态"><span class="badge badge-<?= e($t['status']) ?>"><?= e(status_label($t['status'])) ?></span></td>
              <td data-label="处理客服"><?= $t['agent_name'] ? e($t['agent_name']) : '<span class="muted">未分配</span>' ?></td>
              <td data-label="更新时间" class="mono"><?= e($t['updated_at']) ?></td>
              <td data-label="操作">
                <div class="row-actions">
                  <a class="btn btn-ghost btn-sm" href="agent_ticket_detail.php?id=<?= (int)$t['id'] ?>">查看</a>
                  <?php if ($t['status'] === 'open'): ?>
                    <a class="btn btn-primary btn-sm" href="ticket_status.php?ticket_id=<?= (int)$t['id'] ?>&action=accept&back=agent_tickets.php">接单</a>
                  <?php elseif ($t['status'] !== 'closed'): ?>
                    <a class="btn btn-danger btn-sm" href="ticket_status.php?ticket_id=<?= (int)$t['id'] ?>&action=close&back=agent_tickets.php"
                       data-confirm="确定关闭该工单？">关闭</a>
                  <?php endif; ?>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>

      <?php if ($pages > 1): ?>
        <nav class="pagination">
          <?php for ($i = 1; $i <= $pages; $i++): ?>
            <a class="page-item <?= $i === $page ? 'active' : '' ?>"
               href="?status=<?= e($status) ?>&priority=<?= e($priority) ?>&q=<?= urlencode($kw) ?>&page=<?= $i ?>"><?= $i ?></a>
          <?php endfor; ?>
        </nav>
      <?php endif; ?>
    <?php endif; ?>
  </form>
</div>
<?php include __DIR__ . '/footer.php'; ?>
