<?php
// admin_users.php — 用户 / 客服管理：按角色筛选、搜索、新增客服账户
declare(strict_types=1);
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';

$u = require_agent();

$role = (string)($_GET['role'] ?? 'customer');
if (!in_array($role, ['customer', 'agent'], true)) {
    $role = 'customer';
}
$kw = trim((string)($_GET['q'] ?? ''));

/* ===== 新增客服 ===== */
$errors = [];
$old = ['username' => '', 'email' => ''];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $old['username'] = trim((string)($_POST['username'] ?? ''));
    $old['email']    = trim((string)($_POST['email'] ?? ''));
    $pass = (string)($_POST['password'] ?? '');

    if (mb_strlen($old['username']) < 2) { $errors[] = '用户名至少 2 个字符。'; }
    if (!filter_var($old['email'], FILTER_VALIDATE_EMAIL)) { $errors[] = '邮箱格式不正确。'; }
    if (strlen($pass) < 6) { $errors[] = '密码至少 6 位。'; }

    if (!$errors) {
        $st = db()->prepare('SELECT id FROM users WHERE email = ? LIMIT 1');
        $st->execute([$old['email']]);
        if ($st->fetch()) {
            $errors[] = '该邮箱已存在。';
        }
    }
    if (!$errors) {
        $palette = ['#00e5ff', '#7c4dff', '#00e676', '#ff9100', '#ff5252', '#4a9eff'];
        db()->prepare('INSERT INTO users (username, email, password_hash, role, avatar_color, email_verified_at, created_at)
                       VALUES (?, ?, ?, "agent", ?, NOW(), NOW())')
            ->execute([$old['username'], $old['email'], password_hash($pass, PASSWORD_DEFAULT), $palette[array_rand($palette)]]);
        flash_set('success', '客服账户已创建：' . $old['username']);
        header('Location: admin_users.php?role=agent');
        exit;
    }
}

/* ===== 列表 ===== */
$where  = ['u.role = ?'];
$params = [$role];
if ($kw !== '') {
    $where[] = '(u.username LIKE ? OR u.email LIKE ?)';
    $like = '%' . $kw . '%';
    array_push($params, $like, $like);
}
$whereSql = implode(' AND ', $where);

$st = db()->prepare("SELECT u.*,
        (SELECT COUNT(*) FROM tickets t WHERE t.user_id = u.id) AS ticket_count,
        (SELECT COUNT(*) FROM qq_bindings b WHERE b.user_id = u.id) AS bound
    FROM users u WHERE $whereSql ORDER BY u.id DESC LIMIT 200");
$st->execute($params);
$users = $st->fetchAll();

$IS_AGENT_LAYOUT = true;
$ACTIVE_MENU     = $role === 'agent' ? 'agents' : 'users';
$PAGE_TITLE      = $role === 'agent' ? '客服管理' : '用户管理';
$BREADCRUMB      = ['组织管理', $PAGE_TITLE];
include __DIR__ . '/header.php';
?>
<div class="flex gap8 wrap mb16">
  <a class="tab <?= $role === 'customer' ? 'active' : '' ?>" href="admin_users.php?role=customer">客户</a>
  <a class="tab <?= $role === 'agent' ? 'active' : '' ?>" href="admin_users.php?role=agent">客服</a>
</div>

<?php foreach ($errors as $err): ?><div class="alert alert-danger"><?= e($err) ?></div><?php endforeach; ?>

<div class="card mb16">
  <form method="get" class="table-toolbar">
    <input type="hidden" name="role" value="<?= e($role) ?>">
    <div class="search-box" style="max-width:320px">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>
      <input type="search" name="q" value="<?= e($kw) ?>" placeholder="搜索用户名 / 邮箱">
    </div>
    <button class="btn btn-ghost btn-sm" type="submit">搜索</button>
    <span class="muted" style="margin-left:auto">共 <?= count($users) ?> 条</span>
  </form>

  <div class="table-wrap">
    <table class="data-table responsive">
      <thead><tr><th>ID</th><th>用户名</th><th>邮箱</th><th>邮箱验证</th><th>角色</th><th>QQ 绑定</th><th>工单数</th><th>注册时间</th></tr></thead>
      <tbody>
      <?php if (!$users): ?>
        <tr><td colspan="8" class="muted center">暂无数据</td></tr>
      <?php endif; ?>
      <?php foreach ($users as $row): ?>
        <tr>
          <td data-label="ID" class="mono"><?= (int)$row['id'] ?></td>
          <td data-label="用户名" class="title-cell">
            <span class="avatar sm" style="background:<?= e($row['avatar_color']) ?>;vertical-align:middle"><?= e(initial($row['username'])) ?></span>
            <?= e($row['username']) ?>
          </td>
          <td data-label="邮箱"><?= e($row['email']) ?></td>
          <td data-label="邮箱验证"><?= !empty($row['email_verified_at']) ? '<span style="color:var(--success)">已验证</span>' : '<span class="muted">未验证</span>' ?></td>
          <td data-label="角色"><span class="badge <?= $row['role'] === 'agent' ? 'badge-replied' : 'badge-open' ?>"><?= $row['role'] === 'agent' ? '客服' : '客户' ?></span></td>
          <td data-label="QQ 绑定"><?= (int)$row['bound'] > 0 ? '<span style="color:var(--success)">已绑定</span>' : '<span class="muted">未绑定</span>' ?></td>
          <td data-label="工单数" class="mono"><?= (int)$row['ticket_count'] ?></td>
          <td data-label="注册时间" class="mono"><?= e($row['created_at']) ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<div class="card">
  <h3 class="card-title"><span class="dot"></span>新增客服账户</h3>
  <form method="post" class="form-grid">
    <?= csrf_field() ?>
    <div class="form-group">
      <label for="username">用户名</label>
      <input id="username" name="username" type="text" required value="<?= e($old['username']) ?>">
    </div>
    <div class="form-group">
      <label for="email">邮箱</label>
      <input id="email" name="email" type="email" required value="<?= e($old['email']) ?>">
    </div>
    <div class="form-group">
      <label for="password">初始密码</label>
      <input id="password" name="password" type="password" required placeholder="至少 6 位">
    </div>
    <div class="form-group" style="display:flex;align-items:flex-end">
      <button class="btn btn-primary" type="submit">创建客服</button>
    </div>
  </form>
</div>
<?php include __DIR__ . '/footer.php'; ?>
